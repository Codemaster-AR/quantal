
import React, { useRef, useEffect } from 'react';

// Simple vector class
class Vec2 {
    constructor(public x: number, public y: number) {}
    add(other: Vec2) {
        return new Vec2(this.x + other.x, this.y + other.y);
    }
}

class Orb {
    pos: Vec2;
    vel: Vec2;
    radius: number;
    color: string;

    constructor(x: number, y: number, radius: number, color: string) {
        this.pos = new Vec2(x, y);
        const angle = Math.random() * 2 * Math.PI;
        const speed = 0.2 + Math.random() * 0.3; // Slower, more ambient
        this.vel = new Vec2(Math.cos(angle) * speed, Math.sin(angle) * speed);
        this.radius = radius;
        this.color = color;
    }

    update(bounds: { width: number; height: number }) {
        this.pos = this.pos.add(this.vel);

        if (this.pos.x - this.radius < 0 || this.pos.x + this.radius > bounds.width) {
            this.vel.x *= -1;
        }
        if (this.pos.y - this.radius < 0 || this.pos.y + this.radius > bounds.height) {
            this.vel.y *= -1;
        }
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.beginPath();
        const gradient = ctx.createRadialGradient(
            this.pos.x, this.pos.y, 1,
            this.pos.x, this.pos.y, this.radius
        );
        gradient.addColorStop(0, this.color);
        // Correctly create a transparent version of the hsla color
        const transparentColor = this.color.substring(0, this.color.lastIndexOf(',')) + ', 0)';
        gradient.addColorStop(1, transparentColor);
        ctx.fillStyle = gradient;
        ctx.arc(this.pos.x, this.pos.y, this.radius, 0, 2 * Math.PI);
        ctx.fill();
    }
}


const LiquidBackground: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        let orbs: Orb[] = [];
        
        // Reverted to multicolor scheme
        const colors = [
            'hsla(320, 90%, 50%, 0.4)', 
            'hsla(200, 90%, 50%, 0.4)', 
            'hsla(260, 90%, 50%, 0.4)', 
            'hsla(40, 90%, 50%, 0.4)', 
            'hsla(150, 90%, 50%, 0.4)', 
        ];

        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            
            orbs = [];
            const numOrbs = Math.floor((canvas.width * canvas.height) / 80000);
            for (let i = 0; i < numOrbs; i++) {
                const radius = Math.random() * 200 + 150; // Larger orbs for more ambient feel
                orbs.push(new Orb(
                    Math.random() * canvas.width,
                    Math.random() * canvas.height,
                    radius,
                    colors[i % colors.length]
                ));
            }
        };

        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        
        const animate = () => {
            if (!ctx) return;
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Using 'screen' for glowing effect
            ctx.globalCompositeOperation = 'screen';

            orbs.forEach(orb => {
                orb.update({ width: canvas.width, height: canvas.height });
                orb.draw(ctx);
            });

            animationFrameId = window.requestAnimationFrame(animate);
        };

        animate();

        return () => {
            window.cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, []);

    // Reverted background base
    return <canvas ref={canvasRef} className="absolute inset-0 -z-10 bg-black" />;
};

export default LiquidBackground;
