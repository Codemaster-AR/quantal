
import React, { useState, useEffect, useRef, useCallback, FC, MouseEvent as ReactMouseEvent } from 'react';
import { WindowInstance, AppDefinition, /* Removed SimulatedFile */ ChatMessage, FileSystem, FolderNode, FileNode, FileSystemNode } from './types'; // Updated import
import { APPS, StartIcon, SettingsIcon, AppearanceIcon, ControlCenterIcon, ChatbotIcon } from './constants';
import LiquidBackground from './LiquidBackground';
import { GoogleGenAI, FunctionDeclaration, Type, GenerateContentParameters, FunctionResponse } from '@google/genai';

const WINDOW_HEADER_HEIGHT = 36; // Corresponds to h-9 in Tailwind
const TOP_BAR_HEIGHT = 36; // Corresponds to h-9 in Tailwind
const TASKBAR_HEIGHT = 0; // Desktop now goes to bottom edge

// Sound Effect URLs
const SOUNDS = {
    STARTUP: 'https://actions.google.com/sounds/v1/science_fiction/hum_and_beeps_turning_on.ogg',
    APP_OPEN: 'https://actions.google.com/sounds/v1/ui/click_submit_2.ogg',
    CLICK: 'https://actions.google.com/sounds/v1/ui/click_on_2.ogg' // Optional, can be used for other interactions
};

const playSound = (url: string) => {
    const audio = new Audio(url);
    audio.volume = 0.5;
    audio.play().catch(e => console.log("Audio play failed (user interaction required first):", e));
};

// Map app names to IDs for easier lookup by the model
const APPS_MAP_BY_NAME: { [key: string]: string } = APPS.reduce((acc, app) => {
  acc[app.name.toLowerCase()] = app.id;
  return acc;
}, {});

// --- Window Component ---
interface WindowProps {
  instance: WindowInstance;
  app: AppDefinition;
  isActive: boolean;
  onClose: (id: string) => void;
  onMinimize: (id: string) => void;
  onMaximize: (id: string) => void;
  onFocus: (id: string) => void;
  onUpdate: (id: string, updates: Partial<WindowInstance>) => void;
  desktopSize: { width: number; height: number };
  appSpecificProps?: any; // Added for File Manager and other app context
}

const WindowComponent: FC<WindowProps> = ({ instance, app, isActive, onClose, onMinimize, onMaximize, onFocus, onUpdate, desktopSize, appSpecificProps }) => {
  const windowRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef({ x: 0, y: 0 });
  const resizeRef = useRef({ x: 0, y: 0, width: 0, height: 0, direction: '' });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);

  const handleDragStart = (e: ReactMouseEvent<HTMLDivElement>) => {
    if (instance.isMaximized) return;
    // check if the click is on a button
    if ((e.target as HTMLElement).closest('button')) return;
    e.preventDefault();
    setIsDragging(true);
    onFocus(instance.id);
    dragRef.current = {
      x: e.clientX - instance.position.x,
      y: e.clientY - instance.position.y,
    };
  };

  const handleResizeStart = (e: ReactMouseEvent<HTMLDivElement>, direction: string) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    onFocus(instance.id);
    resizeRef.current = {
      x: e.clientX,
      y: e.clientY,
      width: instance.size.width,
      height: instance.size.height,
      direction,
    };
  };
  
  const handleMouseMove = useCallback((e: MouseEvent) => {
    const RESIZE_MIN_WIDTH = 300;
    const RESIZE_MIN_HEIGHT = 200;

    if (isDragging) {
      let newX = e.clientX - dragRef.current.x;
      let newY = e.clientY - dragRef.current.y;

      // Clamp newX to screen boundaries
      const minX = 0;
      const maxX = desktopSize.width - instance.size.width;
      newX = Math.max(minX, Math.min(newX, maxX));

      // Clamp newY to screen boundaries, respecting the top bar
      const minY = TOP_BAR_HEIGHT;
      const maxY = desktopSize.height - instance.size.height;
      newY = Math.max(minY, Math.min(newY, maxY));
      
      onUpdate(instance.id, { position: { x: newX, y: newY } });
    }
    if (isResizing) {
      const dx = e.clientX - resizeRef.current.x;
      const dy = e.clientY - resizeRef.current.y;

      let tentativeX = instance.position.x;
      let tentativeY = instance.position.y;
      let tentativeWidth = instance.size.width;
      let tentativeHeight = instance.size.height;

      const direction = resizeRef.current.direction;

      // Calculate tentative new dimensions/positions
      if (direction.includes('e')) {
        tentativeWidth = resizeRef.current.width + dx;
      }
      if (direction.includes('s')) {
        tentativeHeight = resizeRef.current.height + dy;
      }
      if (direction.includes('w')) {
        tentativeWidth = resizeRef.current.width - dx;
        tentativeX = instance.position.x + dx;
      }
      if (direction.includes('n')) {
        tentativeHeight = resizeRef.current.height - dy;
        tentativeY = instance.position.y + dy;
      }

      // 1. Clamp tentative width and height to minimums
      tentativeWidth = Math.max(RESIZE_MIN_WIDTH, tentativeWidth);
      tentativeHeight = Math.max(RESIZE_MIN_HEIGHT, tentativeHeight);
      
      // 2. Clamp tentative position (x, y) to desktop boundaries, *considering tentative width/height*.
      const desktopMinX = 0;
      const desktopMinY = TOP_BAR_HEIGHT;
      const desktopMaxX = desktopSize.width - tentativeWidth;
      const desktopMaxY = desktopSize.height - tentativeHeight;

      let finalX = Math.max(desktopMinX, Math.min(tentativeX, desktopMaxX));
      let finalY = Math.max(desktopMinY, Math.min(tentativeY, desktopMaxY));
      
      let finalWidth = tentativeWidth;
      let finalHeight = tentativeHeight;

      // 3. Re-evaluate width/height based on clamped x/y if resizing from 'w' or 'n'
      // This ensures the window doesn't go off-screen if its position was clamped.
      if (direction.includes('w')) {
        // New width is the distance from the new clamped X to the original right edge
        finalWidth = instance.position.x + instance.size.width - finalX;
        finalWidth = Math.max(RESIZE_MIN_WIDTH, finalWidth); // Re-clamp minimum width
        // Also ensure it doesn't extend beyond the desktop if finalX was clamped
        finalWidth = Math.min(finalWidth, desktopSize.width - finalX);
      }
      if (direction.includes('n')) {
        // New height is the distance from the new clamped Y to the original bottom edge
        finalHeight = instance.position.y + instance.size.height - finalY;
        finalHeight = Math.max(RESIZE_MIN_HEIGHT, finalHeight); // Re-clamp minimum height
        // Also ensure it doesn't extend beyond the desktop if finalY was clamped
        finalHeight = Math.min(finalHeight, desktopSize.height - finalY);
      }

      // One final check for minimums after all position/width interdependence adjustments
      finalWidth = Math.max(RESIZE_MIN_WIDTH, finalWidth);
      finalHeight = Math.max(RESIZE_MIN_HEIGHT, finalHeight);

      // And ensure final width/height don't exceed desktop bounds from finalX/Y
      finalWidth = Math.min(finalWidth, desktopSize.width - finalX);
      finalHeight = Math.min(finalHeight, desktopSize.height - finalY);

      onUpdate(instance.id, {
        size: { width: finalWidth, height: finalHeight },
        position: { x: finalX, y: finalY }
      });
    }
  }, [isDragging, isResizing, instance.id, instance.size, instance.position, onUpdate, desktopSize]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsResizing(false);
  }, []);

  useEffect(() => {
    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, handleMouseMove, handleMouseUp]);
  
  const windowStyles: React.CSSProperties = instance.isMaximized ? {
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      transform: 'none',
      zIndex: instance.zIndex,
      borderRadius: 0,
    } : {
      top: instance.position.y,
      left: instance.position.x,
      width: instance.size.width,
      height: instance.size.height,
      zIndex: instance.zIndex,
    };


  if (instance.isMinimized) return null;
  
  const AppContent = app.component;

  return (
    <div
      ref={windowRef}
      className={`absolute flex flex-col bg-light-bg dark:bg-dark-bg backdrop-blur-2xl rounded-xl shadow-2xl border border-light-border dark:border-dark-border transition-all duration-100 ease-out animate-pop-in ${isActive ? 'ring-2 ring-primary' : ''}`}
      style={windowStyles}
      onMouseDown={() => onFocus(instance.id)}
    >
      <header
        className="relative flex items-center h-9 select-none rounded-t-xl group text-black dark:text-white"
        onMouseDown={handleDragStart}
        onDoubleClick={() => onMaximize(instance.id)}
      >
        <div className="flex items-center gap-1 pl-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <button onClick={() => onClose(instance.id)} className="w-7 h-7 rounded flex items-center justify-center hover:bg-red-500 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            <button onClick={() => onMinimize(instance.id)} className="w-7 h-7 rounded flex items-center justify-center hover:bg-white/20">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12h-15" /></svg>
            </button>
            <button onClick={() => onMaximize(instance.id)} className="w-7 h-7 rounded flex items-center justify-center hover:bg-white/20">
                {instance.isMaximized ? (
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 8.25V6a2.25 2.25 0 00-2.25-2.25H6A2.25 2.25 0 003.75 6v8.25A2.25 2.25 0 006 16.5h2.25m8.25-8.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-8.25A2.25 2.25 0 017.5 18v-2.25m8.25-8.25l-6 6" />
                    </svg>
                ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 7.5A2.25 2.25 0 017.5 5.25h9a2.25 2.25 0 012.25 2.25v9a2.25 2.25 0 01-2.25-2.25h-9a2.25 2.25 0 01-2.25-2.25v-9z" />
                    </svg>
                )}
            </button>
        </div>
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center gap-2 text-sm pointer-events-none">
          <span className="w-4 h-4">{app.icon}</span>
          <span>{instance.title}</span>
        </div>
      </header>
      <main className="flex-grow rounded-b-xl overflow-hidden">
        <AppContent {...appSpecificProps} />
      </main>
      
      {!instance.isMaximized && <>
        <div onMouseDown={(e) => handleResizeStart(e, 'n')} className="absolute -top-1 left-1 right-1 h-2 cursor-n-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 's')} className="absolute -bottom-1 left-1 right-1 h-2 cursor-s-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 'w')} className="absolute -left-1 top-1 bottom-1 w-2 cursor-w-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 'e')} className="absolute -right-1 top-1 bottom-1 w-2 cursor-e-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 'nw')} className="absolute -top-1 -left-1 w-3 h-3 cursor-nw-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 'ne')} className="absolute -top-1 -right-1 w-3 h-3 cursor-ne-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 'sw')} className="absolute -bottom-1 -left-1 w-3 h-3 cursor-sw-resize"></div>
        <div onMouseDown={(e) => handleResizeStart(e, 'se')} className="absolute -bottom-1 -right-1 w-3 h-3 cursor-se-resize"></div>
      </>}
    </div>
  );
};

// --- Other Components ---

const AppLauncher: FC<{ onOpenApp: (id: string) => void, closeMenu: () => void }> = ({ onOpenApp, closeMenu }) => {
    const menuRef = useRef<HTMLDivElement>(null);
    const [internalQuery, setInternalQuery] = useState('');

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && menuRef.current === event.target) {
                closeMenu();
            }
        };
        const handleEsc = (event: KeyboardEvent) => {
            if(event.key === 'Escape') closeMenu();
        }
        document.addEventListener('mousedown', handleClickOutside);
        document.addEventListener('keydown', handleEsc);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleEsc);
        }
    }, [closeMenu]);

    const filteredApps = APPS.filter(app => 
        app.name.toLowerCase().includes(internalQuery.toLowerCase())
    );

    return (
        <div ref={menuRef} className="fixed inset-0 z-40 bg-black/20 backdrop-blur-2xl flex flex-col items-center justify-center p-8 animate-fade-in">
            <div className="w-full max-w-4xl">
                 <input 
                    type="text" 
                    placeholder="Search apps..." 
                    value={internalQuery}
                    onChange={(e) => setInternalQuery(e.target.value)}
                    className="w-full max-w-lg mx-auto block mb-8 px-4 py-2 rounded-full bg-white/20 text-white placeholder:text-gray-300 border-none focus:ring-2 focus:ring-primary"
                    autoFocus
                 />
                <div className="grid grid-cols-6 gap-8">
                    {filteredApps.map(app => (
                        <div key={app.id} onClick={() => { onOpenApp(app.id); closeMenu(); }} className="flex flex-col items-center gap-2 p-2 rounded-lg hover:bg-white/10 cursor-pointer transition-colors">
                            <span className="w-12 h-12 text-white drop-shadow-lg">{app.icon}</span>
                            <span className="text-sm text-white text-center drop-shadow-lg">{app.name}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const TopBar: FC<{
  isDarkMode: boolean;
  setIsDarkMode: (value: boolean) => void;
  onOpenApp: (id: string) => void;
}> = ({ isDarkMode, setIsDarkMode, onOpenApp }) => {
    const [time, setTime] = useState(new Date());
    const [isControlCenterOpen, setIsControlCenterOpen] = useState(false);
    const controlCenterRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (controlCenterRef.current && !controlCenterRef.current.contains(event.target as Node)) {
                setIsControlCenterOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <div className="fixed top-0 left-0 right-0 h-9 z-30 bg-white/20 dark:bg-black/20 backdrop-blur-md border-b border-white/10 dark:border-black/10 transition-colors duration-500">
            <div className="flex justify-end items-center h-full px-4 gap-4 text-black dark:text-white">
                <div className="text-center text-sm">
                    <span>{time.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}</span>
                    <span className="ml-2 font-semibold">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                
                <div className="relative" ref={controlCenterRef}>
                    <button onClick={() => setIsControlCenterOpen(o => !o)} className="p-1 rounded-md hover:bg-white/20">
                        <ControlCenterIcon className="w-5 h-5"/>
                    </button>
                    {isControlCenterOpen && (
                        <div className="absolute top-full right-0 mt-2 w-64 p-2 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-lg border border-light-border dark:border-dark-border shadow-2xl animate-pop-in origin-top-right">
                            <h3 className="px-2 pb-1 text-sm font-semibold">Control Center</h3>
                            <div className="my-1 border-t border-light-border dark:border-dark-border"></div>
                            
                            <div onClick={() => { onOpenApp('settings'); setIsControlCenterOpen(false); }} className="flex items-center gap-3 p-2 rounded-md hover:bg-primary/80 hover:text-white cursor-pointer transition-colors">
                                <SettingsIcon className="w-5 h-5"/>
                                <span className="text-sm">Settings</span>
                            </div>

                            <div className="flex items-center justify-between p-2 rounded-md">
                                <div className="flex items-center gap-3">
                                  <AppearanceIcon className="w-5 h-5"/>
                                  <span className="text-sm">Theme</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="text-xs">Light</span>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" checked={isDarkMode} onChange={() => setIsDarkMode(!isDarkMode)} className="sr-only peer" />
                                        <div className="w-11 h-6 bg-gray-300 rounded-full peer peer-focus:ring-2 peer-focus:ring-primary dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                                    </label>
                                    <span className="text-xs">Dark</span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const SearchResultsPopup: FC<{ apps: AppDefinition[]; onOpenApp: (id: string) => void; }> = ({ apps, onOpenApp }) => (
    <div className="absolute bottom-full mb-2 w-64 max-h-60 overflow-y-auto p-2 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-lg border border-light-border dark:border-dark-border shadow-lg animate-pop-in origin-bottom">
        {apps.length > 0 ? (
            apps.map(app => (
                <div
                    key={app.id}
                    onClick={() => onOpenApp(app.id)}
                    className="flex items-center gap-3 p-2 rounded-md hover:bg-primary hover:text-white cursor-pointer transition-colors text-black dark:text-white"
                >
                    <span className="w-6 h-6">{app.icon}</span>
                    <span className="text-sm">{app.name}</span>
                </div>
            ))
        ) : (
            <div className="p-2 text-center text-sm text-gray-600 dark:text-gray-400">No apps found.</div>
        )}
    </div>
);

const SearchBar: FC<{ value: string; onChange: (value: string) => void; onFocus: () => void; }> = ({ value, onChange, onFocus }) => (
    <div className="relative flex items-center w-64 h-12 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-full border border-light-border dark:border-dark-border shadow-lg transition-all focus-within:ring-2 ring-primary">
        <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-black dark:text-white">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
            </svg>
        </div>
        <input
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={onFocus}
            placeholder="Search LiquidOS..."
            className="w-full h-full pl-11 pr-4 bg-transparent text-black dark:text-white placeholder:text-gray-600 dark:placeholder:text-gray-400 focus:outline-none"
        />
    </div>
);


const ChatbotPopup: FC<{
  messages: ChatMessage[];
  inputValue: string;
  onInputChange: (value: string) => void;
  onSendMessage: () => void;
  isBotTyping: boolean;
}> = ({ messages, inputValue, onInputChange, onSendMessage, isBotTyping }) => {
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isBotTyping]);

    return (
        <div className="absolute bottom-full mb-2 w-80 h-96 flex flex-col bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-lg border border-light-border dark:border-dark-border shadow-lg text-black dark:text-white animate-pop-in origin-bottom-left">
            <h3 className="font-semibold text-sm p-2 border-b border-light-border dark:border-dark-border">LiquidOS AI</h3>
            <div className="flex-grow p-2 overflow-y-auto space-y-3">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-2 rounded-lg text-sm break-words ${msg.sender === 'user' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                {isBotTyping && (
                     <div className="flex justify-start">
                        <div className="p-2 rounded-lg text-sm bg-gray-200 dark:bg-gray-700">
                            <div className="flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-pulse"></span>
                                <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-pulse [animation-delay:0.2s]"></span>
                                <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-pulse [animation-delay:0.4s]"></span>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <form
                onSubmit={(e) => {
                    e.preventDefault();
                    onSendMessage();
                }}
                className="p-2 border-t border-light-border dark:border-dark-border flex items-center gap-2"
            >
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => onInputChange(e.target.value)}
                    placeholder="Ask LiquidOS AI..."
                    className="flex-grow h-9 px-3 bg-white/50 dark:bg-black/20 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-sm"
                />
                <button type="submit" className="p-2 rounded-md bg-primary hover:bg-primary/90 text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path></svg>
                </button>
            </form>
        </div>
    );
};

const DesktopIcon: FC<{ app: AppDefinition, onOpen: (id: string) => void, clickBehavior: 'single' | 'double' }> = ({ app, onOpen, clickBehavior }) => (
    <div 
        onClick={() => clickBehavior === 'single' && onOpen(app.id)}
        onDoubleClick={() => clickBehavior === 'double' && onOpen(app.id)} 
        className="flex flex-col items-center w-24 p-2 rounded-lg hover:bg-white/10 cursor-pointer group transition-all duration-200"
    >
        <span className="w-12 h-12 drop-shadow-lg group-hover:scale-110 transition-transform duration-200">{app.icon}</span>
        <span className="mt-1 text-sm text-center shadow-black [text-shadow:1px_1px_2px_var(--tw-shadow-color)]">{app.name}</span>
    </div>
);

const StartupScreen: FC<{ onComplete: () => void }> = ({ onComplete }) => {
    useEffect(() => {
        const handleInteraction = () => {
            playSound(SOUNDS.STARTUP);
            onComplete();
        };

        window.addEventListener('keydown', handleInteraction);
        window.addEventListener('click', handleInteraction);
        window.addEventListener('touchstart', handleInteraction);

        return () => {
            window.removeEventListener('keydown', handleInteraction);
            window.removeEventListener('click', handleInteraction);
            window.removeEventListener('touchstart', handleInteraction);
        };
    }, [onComplete]);

    return (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white font-sans bg-black/20 backdrop-blur-sm select-none">
            <div className="flex flex-col items-center">
                <p className="text-xl md:text-2xl font-light mb-4 tracking-wide opacity-90 animate-[fade-in_2s_ease-out]">Welcome to</p>
                <h1 className="text-6xl md:text-8xl font-bold tracking-tight mb-8 animate-[fade-in_3s_ease-out]">
                    <span className="text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]">Liquid</span> <span className="text-primary drop-shadow-[0_0_15px_rgba(0,122,255,0.8)]">OS</span>
                </h1>
            </div>

            <div className="absolute bottom-16 z-10 animate-pulse">
                <p className="text-sm md:text-base font-medium tracking-[0.2em] text-gray-300 uppercase opacity-80">Press any key to continue</p>
            </div>
        </div>
    );
};


const App: FC = () => {
  const [windows, setWindows] = useState<WindowInstance[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);
  const [nextZIndex, setNextZIndex] = useState(10);
  const [launcherOpen, setLauncherOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [clickBehavior, setClickBehavior] = useState<'single' | 'double'>('double');
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number } | null>(null);
  
  // Replaced 'booting' boolean with 'bootPhase' state to manage transitions
  const [bootPhase, setBootPhase] = useState<'startup' | 'transition' | 'desktop'>('startup');
  
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  // Replaced files: SimulatedFile[] with fileSystem
  const [fileSystem, setFileSystem] = useState<FileSystem>(new Map());
  const rootFolderId = 'root-folder-id';
  const downloadsFolderId = 'downloads-folder-id';

  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { sender: 'bot', text: 'Hello! How can I help you today?' }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isBotTyping, setIsBotTyping] = useState(false);
  
  const desktopRef = useRef<HTMLDivElement>(null);
  const bottomControlsRef = useRef<HTMLDivElement>(null);

  // Initialize File System
  useEffect(() => {
    const initialFileSystem = new Map<string, FileSystemNode>();
    
    const rootFolder: FolderNode = {
      id: rootFolderId,
      name: 'root',
      parentId: null,
      type: 'folder',
      childrenIds: [],
    };
    initialFileSystem.set(rootFolderId, rootFolder);

    const downloadsFolder: FolderNode = {
      id: downloadsFolderId,
      name: 'Downloads',
      parentId: rootFolderId,
      type: 'folder',
      childrenIds: [],
    };
    initialFileSystem.set(downloadsFolderId, downloadsFolder);
    rootFolder.childrenIds.push(downloadsFolderId); // Add downloads to root

    setFileSystem(initialFileSystem);
  }, []); // Run only once on mount

  // Function to add a downloaded file to the file system
  const addDownloadedFile = useCallback((name: string, url: string, mimeType: string) => {
    setFileSystem(prev => {
      const newFs = new Map(prev);
      const newFileId = `file-${Date.now()}`;
      const newFile: FileNode = {
        id: newFileId,
        name: name,
        parentId: downloadsFolderId, // Always add downloaded files to the Downloads folder
        type: 'file',
        mimeType: mimeType,
        url: url,
      };
      newFs.set(newFileId, newFile);

      const downloadsFolder = newFs.get(downloadsFolderId) as FolderNode;
      if (downloadsFolder) {
        newFs.set(downloadsFolderId, {
          ...downloadsFolder,
          childrenIds: [...downloadsFolder.childrenIds, newFileId],
        });
      }
      return newFs;
    });
  }, []);
  
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
  }, [isDarkMode]);

  // Effect to ensure active window is always valid
  useEffect(() => {
    const activeWindow = windows.find(w => w.id === activeWindowId);
    if (activeWindowId && (!activeWindow || activeWindow.isMinimized)) {
      const newActiveWindow = windows.filter(w => !w.isMinimized).sort((a, b) => b.zIndex - a.zIndex)[0];
      setActiveWindowId(newActiveWindow ? newActiveWindow.id : null);
    }
  }, [windows, activeWindowId]);
  
  // Effect for closing menus/popups on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (contextMenu) {
            closeContextMenu();
        }
        if (bottomControlsRef.current && !bottomControlsRef.current.contains(event.target as Node)) {
            setIsSearchFocused(false);
            setIsChatbotOpen(false);
        }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, [contextMenu]);

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        if (launcherOpen) setLauncherOpen(false);
        if (isSearchFocused) {
          setIsSearchFocused(false);
          (document.activeElement as HTMLElement)?.blur();
        }
        if(isChatbotOpen) setIsChatbotOpen(false);
      }
    }
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [launcherOpen, isSearchFocused, isChatbotOpen]);

  const focusWindow = (id: string) => {
    if (id === activeWindowId) return;
    const newZIndex = nextZIndex + 1;
    setWindows(prev => prev.map(w => w.id === id ? { ...w, zIndex: newZIndex } : w));
    setActiveWindowId(id);
    setNextZIndex(newZIndex);
  };

  const openApp = (appId: string, fileId?: string) => { // Modified to accept fileId
    const app = APPS.find(a => a.id === appId);
    if (!app) return;

    playSound(SOUNDS.APP_OPEN); // Play sound on open

    const existingWindows = windows.filter(w => w.appId === appId);

    if (existingWindows.length > 0) {
      const topWindow = existingWindows.sort((a, b) => b.zIndex - a.zIndex)[0];
      if (topWindow.isMinimized) {
        const newZIndex = nextZIndex + 1;
        setWindows(prev => prev.map(w => w.id === topWindow.id ? { ...w, isMinimized: false, zIndex: newZIndex, appSpecificProps: fileId ? { fileId } : undefined } : w));
        setActiveWindowId(topWindow.id);
        setNextZIndex(newZIndex);
      } else {
        // If app is already open and not minimized, just focus it
        // If opening with a specific fileId, update existing window's props
        setWindows(prev => prev.map(w => w.id === topWindow.id ? { ...w, appSpecificProps: fileId ? { fileId } : undefined } : w));
        focusWindow(topWindow.id);
      }
    } else {
      const newWindowId = `${appId}-${Date.now()}`;
      const newZIndex = nextZIndex + 1;
      const openWindowCount = windows.filter(w => !w.isMinimized).length;
      const newWindow: WindowInstance = {
        id: newWindowId,
        appId: appId,
        title: app.name,
        position: { x: 50 + (openWindowCount % 10) * 30, y: 50 + (openWindowCount % 10) * 30 },
        size: { width: 800, height: 600 },
        isMinimized: false,
        isMaximized: !!app.opensMaximized,
        zIndex: newZIndex,
        appSpecificProps: fileId ? { fileId } : undefined, // Attach fileId here
      };
      setWindows(prev => [...prev, newWindow]);
      setActiveWindowId(newWindowId);
      setNextZIndex(newZIndex);
    }
  };

  const closeWindow = (id: string) => {
    setWindows(prev => prev.filter(w => w.id !== id));
  };

  const onMinimize = (id: string) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, isMinimized: !w.isMinimized } : w));
  };

  const onMaximize = (id: string) => {
    setWindows(prev => prev.map(w => {
      if (w.id === id) {
        if (w.isMaximized) {
          return { ...w, isMaximized: false, prevSize: w.size, prevPosition: w.position }; // Fixed issue where prevSize/Position might be missing after maximize -> minimize -> restore.
        } else {
          return { ...w, isMaximized: true, prevSize: w.size, prevPosition: w.position };
        }
      }
      return w;
    }));
  };

  const updateWindowState = (id: string, updates: Partial<WindowInstance>) => {
    setWindows(prev => prev.map(w => w.id === id ? { ...w, ...updates } : w));
  };

  const handleContextMenu = (e: ReactMouseEvent) => {
      e.preventDefault();
      if ((e.target as HTMLElement).closest('[data-no-context]')) return;
      setContextMenu({ x: e.clientX, y: e.clientY });
  };
  
  const closeContextMenu = () => setContextMenu(null);

  const handleOpenAppFromSearch = (appId: string) => {
    openApp(appId);
    setSearchQuery('');
    setIsSearchFocused(false);
  };

  const executeOpenApp = useCallback((appName: string): boolean => {
    console.log(`[Function Call] Attempting to open app: "${appName}"`);
    const appId = APPS_MAP_BY_NAME[appName.toLowerCase()];
    if (appId) {
      openApp(appId); // Use the existing openApp function
      console.log(`[Function Call] Successfully opened "${appName}" (ID: ${appId}).`);
      return true;
    }
    console.warn(`[Function Call] Failed to open "${appName}": App ID not found or app name is incorrect.`);
    return false;
  }, [openApp]);

  const executeCloseApp = useCallback((appName: string): boolean => {
    console.log(`[Function Call] Attempting to close app: "${appName}"`);
    const appId = APPS_MAP_BY_NAME[appName.toLowerCase()];
    if (appId) {
      const instancesToClose = windows.filter(w => w.appId === appId);
      if (instancesToClose.length > 0) {
        instancesToClose.forEach(instance => closeWindow(instance.id)); // Use the existing closeWindow function
        console.log(`[Function Call] Successfully closed all instances of "${appName}".`);
        return true;
      }
    }
    console.warn(`[Function Call] Failed to close "${appName}": No running instances found or App ID not found.`);
    return false;
  }, [windows, closeWindow]);


  const handleSendMessage = async () => {
    const userMessage = chatInput.trim();
    if (!userMessage) return;

    setChatMessages(prev => [...prev, { sender: 'user', text: userMessage }]);
    setChatInput('');
    setIsBotTyping(true);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const openAppDeclaration: FunctionDeclaration = {
            name: 'openApp',
            parameters: {
                type: Type.OBJECT,
                description: 'Opens an application by its name. The appName parameter MUST be one of the following exact, case-sensitive names: ' + APPS.map(app => app.name).join(', ') + '.',
                properties: {
                    appName: {
                        type: Type.STRING,
                        description: 'The exact name of the application to open (e.g., "Settings", "Notepad", "Browser").',
                    },
                },
                required: ['appName'],
            },
        };

        const closeAppDeclaration: FunctionDeclaration = {
            name: 'closeApp',
            parameters: {
                type: Type.OBJECT,
                description: 'Closes an application by its name. The appName parameter MUST be one of the following exact, case-sensitive names: ' + APPS.map(app => app.name).join(', ') + '.',
                properties: {
                    appName: {
                        type: Type.STRING,
                        description: 'The exact name of the application to close (e.g., "Settings", "Notepad", "Browser").',
                    },
                },
                required: ['appName'],
            },
        };

        const tools = [{ functionDeclarations: [openAppDeclaration, closeAppDeclaration] }];

        // The list of all available app names for the AI's reference.
        const allAppNames = APPS.map(app => app.name).join('", "');

        // REFINED SYSTEM INSTRUCTION
        const systemInstruction = `You are LiquidOS AI, a helpful assistant. Your primary and most important function is to manage applications within LiquidOS by utilizing the provided tools.
-   **CRITICAL DIRECTIVE**: If the user's request is to open or launch an application, you **MUST** use the \`openApp\` tool. The \`appName\` parameter **MUST** be the exact, case-sensitive name of the application from the following list: "${allAppNames}".
    *   Examples:
        *   User: "Open Notepad" -> Call \`openApp(appName: "Notepad")\`
        *   User: "Launch Settings" -> Call \`openApp(appName: "Settings")\`
        *   User: "Can you open the Browser?" -> Call \`openApp(appName: "Browser")\`
-   **CRITICAL DIRECTIVE**: If the user's request is to close, shut down, or exit an application, you **MUST** use the \`closeApp\` tool. The \`appName\` parameter **MUST** be the exact, case-sensitive name of the application from the list: "${allAppNames}".
    *   Examples:
        *   User: "Close Calculator" -> Call \`closeApp(appName: "Calculator")\`
        *   User: "Shut down Terminal" -> Call \`closeApp(appName: "Terminal")\`
-   If asked "which model are you", respond with "I am the LiquidOS assistant.".
-   For any other requests that *do not* involve opening or closing applications, provide a helpful and concise natural language response.`;

        // Add a strong preamble to the user's message to prime the model for tool use
        const effectiveUserMessage = `You are LiquidOS AI. Here are the apps you can control: "${allAppNames}". When I ask you to open or close an app, ALWAYS use the provided tools, specifically "openApp" or "closeApp". My request: ${userMessage}`;
        
        console.log("Effective User Message to Gemini:", effectiveUserMessage); // Log the full message being sent

        let currentContents: GenerateContentParameters['contents'] = [{ text: effectiveUserMessage }];

        // First call to Gemini
        const geminiResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: currentContents,
            config: {
                systemInstruction: systemInstruction,
            },
            tools: tools,
        });

        console.log("Gemini Raw Response (first call):", geminiResponse);
        console.log("Gemini Function Calls (first call):", geminiResponse.functionCalls);
        console.log("Gemini Text Response (first call):", geminiResponse.text);


        if (geminiResponse.functionCalls && geminiResponse.functionCalls.length > 0) {
            const functionResponses: FunctionResponse[] = [];
            let botInitialMessages: string[] = []; // Collect messages for the bot's immediate response

            for (const fc of geminiResponse.functionCalls) {
                let success = false;
                if (fc.name === 'openApp') {
                    const appName = fc.args.appName as string;
                    botInitialMessages.push(`Attempting to open ${appName}...`);
                    success = executeOpenApp(appName);
                } else if (fc.name === 'closeApp') {
                    const appName = fc.args.appName as string;
                    botInitialMessages.push(`Attempting to close ${appName}...`);
                    success = executeCloseApp(appName);
                }
                functionResponses.push({
                    id: fc.id,
                    name: fc.name,
                    response: { result: success ? "success" : "failure" },
                });
            }
            
            // Add initial bot messages about executing the command (e.g., "Attempting to open...")
            setChatMessages(prev => [...prev, ...botInitialMessages.map(msg => ({ sender: 'bot', text: msg }))]);

            // Append tool output to contents for a second call to get a natural language response
            // The model needs to know the outcome of the tool call to formulate its response.
            currentContents = [
                ...currentContents,
                {
                  toolResponse: {
                      functionResponses: functionResponses,
                  },
                },
            ];

            // Second call to Gemini with Tool Response to get a natural language follow-up
            const followUpResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: currentContents,
                config: {
                    systemInstruction: systemInstruction, // Maintain system instruction
                },
                tools: tools, // Important to keep tools for consistent context
            });

            const botResponseText = followUpResponse.text || "I have processed your request.";
            setChatMessages(prev => [...prev, { sender: 'bot', text: botResponseText }]);

        } else if (userMessage.toLowerCase().includes("which model are you")) {
            setChatMessages(prev => [...prev, { sender: 'bot', text: 'I am the LiquidOS assistant.' }]);
        } else if (geminiResponse.text) {
            setChatMessages(prev => [...prev, { sender: 'bot', text: geminiResponse.text }]);
        } else {
            // IMPROVED FALLBACK MESSAGE
            console.warn("Gemini did not return any function calls or text for this input."); 
            setChatMessages(prev => [...prev, { sender: 'bot', text: "I'm sorry, I couldn't find a command to open or close an app for that request. To open or close an app, please be specific, for example: 'Open Settings' or 'Close Notepad'." }]);
        }

    } catch (error) {
        console.error("Chatbot API error:", error);
        const errorMessage = (error instanceof Error) ? error.message : 'An unknown error occurred.';
        setChatMessages(prev => [...prev, { sender: 'bot', text: `Error: ${errorMessage}. Please check your API key and ensure it has access to the Gemini API.` }]);
    } finally {
        setIsBotTyping(false);
    }
  };

  const filteredAppsForSearch = APPS.filter(app =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isAnyWindowMaximized = windows.some(w => w.isMaximized && !w.isMinimized);

  return (
    <div onContextMenu={handleContextMenu} className={`h-screen w-screen overflow-hidden font-sans text-white`}>
        <LiquidBackground />
        
        {bootPhase !== 'startup' && (
            <div className={`contents ${bootPhase === 'transition' ? 'animate-desktop-enter' : ''}`}>
                {!isAnyWindowMaximized && <TopBar 
                  isDarkMode={isDarkMode} 
                  setIsDarkMode={setIsDarkMode} 
                  onOpenApp={openApp}
                />}

                <div ref={desktopRef} className="absolute inset-0">
                    <div className="p-4 pt-12 flex flex-col flex-wrap h-full content-start">
                        {APPS.filter(app => app.isDesktopShortcut).map(app => (
                            <DesktopIcon key={app.id} app={app} onOpen={openApp} clickBehavior={clickBehavior} />
                        ))}
                    </div>

                    {windows.map(instance => {
                        const app = APPS.find(a => a.id === instance.appId);
                        if (!app) return null;
                        
                        // Prop handling for apps that need global state
                        const appSpecificProps: { [key: string]: any } = {
                            ...instance.appSpecificProps, // Pass fileId if present
                        };
                        if (app.id === 'settings') {
                            Object.assign(appSpecificProps, { isDarkMode, setIsDarkMode, clickBehavior, setClickBehavior });
                        }
                        // Pass fileSystem and setter to apps that need to interact with it
                        if (['browser', 'liquid-book-reader', 'file-manager', 'notepad'].includes(app.id)) {
                            Object.assign(appSpecificProps, { fileSystem, setFileSystem });
                        }
                        if (app.id === 'browser') {
                            Object.assign(appSpecificProps, { addDownloadedFile });
                        }
                        if (app.id === 'file-manager') {
                            Object.assign(appSpecificProps, { rootFolderId, openApp }); // File Manager needs openApp to open files
                        }


                        return (
                            <WindowComponent
                                key={instance.id}
                                instance={instance}
                                app={app}
                                isActive={activeWindowId === instance.id}
                                onClose={closeWindow}
                                onMinimize={onMinimize}
                                onMaximize={onMaximize}
                                onFocus={focusWindow}
                                onUpdate={updateWindowState}
                                desktopSize={{
                                    width: desktopRef.current?.clientWidth || window.innerWidth,
                                    height: desktopRef.current?.clientHeight || window.innerHeight - TASKBAR_HEIGHT,
                                }}
                                appSpecificProps={appSpecificProps}
                            />
                        );
                    })}
                </div>
                
                {launcherOpen && <AppLauncher 
                    onOpenApp={openApp} 
                    closeMenu={() => setLauncherOpen(false)}
                />}
                
                {contextMenu && (
                    <div 
                      style={{ top: contextMenu.y, left: contextMenu.x }}
                      className="absolute z-50 w-48 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-lg shadow-2xl border border-light-border dark:border-dark-border p-1 text-black dark:text-white animate-pop-in"
                    >
                      <div onClick={() => setIsDarkMode(!isDarkMode)} className="px-3 py-1.5 text-sm rounded-md hover:bg-primary hover:text-white cursor-pointer transition-colors">
                        Toggle {isDarkMode ? "Light" : "Dark"} Mode
                      </div>
                       <div onClick={() => window.location.reload()} className="px-3 py-1.5 text-sm rounded-md hover:bg-primary hover:text-white cursor-pointer transition-colors">
                        Refresh
                      </div>
                    </div>
                )}
                
                {!isAnyWindowMaximized && (
                  <>
                    <div ref={bottomControlsRef} className="fixed bottom-5 left-5 z-30 flex items-center gap-2" data-no-context>
                        <div className="relative">
                          <SearchBar 
                              value={searchQuery}
                              onChange={setSearchQuery}
                              onFocus={() => { setIsSearchFocused(true); setIsChatbotOpen(false); }}
                          />
                          {isSearchFocused && searchQuery && (
                              <SearchResultsPopup apps={filteredAppsForSearch} onOpenApp={handleOpenAppFromSearch} />
                          )}
                        </div>
                        <div className="relative">
                           <button 
                             onClick={() => { setIsChatbotOpen(o => !o); setIsSearchFocused(false); }}
                             className="w-12 h-12 flex items-center justify-center bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-full border border-light-border dark:border-dark-border shadow-lg transition-colors hover:ring-2 ring-primary"
                           >
                             <ChatbotIcon className="w-6 h-6 text-black dark:text-white" />
                           </button>
                           {isChatbotOpen && (
                             <ChatbotPopup 
                                messages={chatMessages}
                                inputValue={chatInput}
                                onInputChange={setChatInput}
                                onSendMessage={handleSendMessage}
                                isBotTyping={isBotTyping}
                             />
                           )}
                        </div>
                    </div>

                    {/* Dock */}
                    <div data-no-context className="absolute bottom-4 left-1/2 -translate-x-1/2 z-50">
                        <div className='flex items-center justify-center h-16 px-4 gap-3 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-2xl border border-light-border dark:border-dark-border shadow-2xl animate-pop-in origin-bottom'>
                            <button onClick={() => setLauncherOpen(!launcherOpen)} className={`p-2 rounded-lg transition-colors ${launcherOpen ? 'bg-primary/80' : 'hover:bg-white/20'}`}>
                                <StartIcon className="h-6 w-6"/>
                            </button>
                            <div className="w-px h-8 bg-white/20"></div>
                            {APPS
                                .filter(app => app.isPinned || windows.some(w => w.appId === app.id))
                                .map(app => {
                                const runningWindows = windows.filter(w => w.appId === app.id);
                                const isRunning = runningWindows.length > 0;
                                
                                const handleDockClick = () => {
                                    if (isRunning) {
                                        const topWindow = runningWindows.sort((a,b) => b.zIndex - a.zIndex)[0];
                                        if (activeWindowId === topWindow.id && !topWindow.isMinimized) {
                                            onMinimize(topWindow.id);
                                        } else {
                                            const newZIndex = nextZIndex + 1;
                                            setWindows(prev => 
                                            prev.map(w => w.id === topWindow.id 
                                                ? { ...w, isMinimized: false, zIndex: newZIndex }
                                                : w
                                            )
                                            );
                                            setActiveWindowId(topWindow.id);
                                            setNextZIndex(newZIndex);
                                        }
                                    } else {
                                        openApp(app.id);
                                    }
                                }

                                return (
                                    <button key={app.id} onClick={handleDockClick} className="p-2 relative group">
                                        <span className="w-8 h-8 flex items-center justify-center transition-transform group-hover:scale-110">{app.icon}</span>
                                        {isRunning && <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-primary rounded-full`}></div>}
                                    </button>
                                )
                            })}
                        </div>
                    </div>
                  </>
                )}
            </div>
        )}
        
        {bootPhase !== 'desktop' && (
             <div className={`absolute inset-0 z-[100] ${bootPhase === 'transition' ? 'animate-startup-exit pointer-events-none' : ''}`}>
                <StartupScreen onComplete={() => {
                    setBootPhase('transition');
                    // Match the longest animation time (1.5s for desktop-enter)
                    setTimeout(() => setBootPhase('desktop'), 1500);
                }} />
             </div>
        )}
    </div>
  );
};

export default App;
