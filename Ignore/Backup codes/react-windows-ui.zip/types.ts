
// FIX: Switched to namespace import for React to ensure JSX types are resolved correctly.
import * as React from 'react';

export interface AppDefinition {
  id: string;
  name: string;
  icon: React.JSX.Element;
  component: React.FC<any>; // Allow any props for app components
  isDesktopShortcut?: boolean;
  isPinned?: boolean;
  opensMaximized?: boolean;
}

export interface WindowInstance {
  id: string;
  appId: string;
  title: string;
  position: { x: number; y: number };
  size: { width: number; height: number };
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  prevSize?: { width: number; height: number };
  prevPosition?: { x: number; y: number };
  appSpecificProps?: any; // Added to pass fileId etc.
}

// Replaced by FileNode and managed by FileSystem
// export interface SimulatedFile {
//   id: string;
//   name: string;
//   type: 'epub' | 'pdf' | 'other';
//   url: string;
// }

export interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
}

export type Reminders = {
  [dateString: string]: string[]; // "YYYY-MM-DD": ["Reminder 1", "Reminder 2"]
};


// New types for File Manager
export interface FileNode {
  id: string;
  name: string;
  parentId: string | null; // null for root files
  type: 'file';
  mimeType: string; // e.g., 'text/plain', 'image/jpeg', 'application/pdf', 'application/epub+zip', 'application/octet-stream'
  content?: string; // For text files
  url?: string; // For files loaded from external URLs (e.g., downloads)
}

export interface FolderNode {
  id: string;
  name: string;
  parentId: string | null; // null for root folder
  type: 'folder';
  childrenIds: string[]; // IDs of children (files or folders)
}

export type FileSystemNode = FileNode | FolderNode;

export type FileSystem = Map<string, FileSystemNode>;