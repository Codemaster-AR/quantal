
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AppDefinition, /* Removed SimulatedFile */ Reminders, FileSystem, FileNode, FolderNode, FileSystemNode } from './types'; // Added FileSystem types

// Let TS know that ePub is available on the window object from the script tag
declare var ePub: any;

// --- Icons ---
export const StartIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 8.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6A2.25 2.25 0 0115.75 3.75h2.25A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25A2.25 2.25 0 0113.5 8.25V6zM13.5 15.75A2.25 2.25 0 0115.75 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25h-2.25a2.25 2.25 0 01-2.25-2.25v-2.25z" />
    </svg>
);
const FolderIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 12H4V6h5.17l2 2H20v10z" /></svg>
);
const NoteIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" /></svg>
);
const BrowserIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v2h-2zm0 4h2v6h-2z" /></svg>
);
export const SettingsIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49.42l.38-2.65c.61-.25 1.17-.59 1.69.98l2.49 1c.23.09.49 0 .61.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z" /></svg>
);
const TrashIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" />
    </svg>
);
const ClockIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);
const TerminalIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M4 3h16c.55 0 1 .45 1 1v16c0 .55-.45 1-1 1H4c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1zm2 11h4v-2H6v2zm0 4h8v-2H6v2zm11-6.41-2.12 2.12-1.41-1.41L15.59 9l-2.12-2.12 1.41-1.41L17 7.59l2.12-2.12 1.41 1.41L18.41 9l2.12 2.12-1.41 1.41L17 10.41z" />
    </svg>
);
const BookIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z" />
    </svg>
);
const PDFIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm-1.5-2.5H9v1h.5c.28 0 .5-.22.5-.5s-.22-.5-.5-.5zm4.5 4.5h-2V14h2c.83 0 1.5-.67 1.5-1.5v-3c0-.83-.67-1.5-1.5-1.5h-2.5v6H13v-1.5h1.5v-1zm-1.5-2.5H13V8h-1.5v1.5zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6z"/>
    </svg>
);
const OneCompilerIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5l3 2.25-3 2.25m4.5 0h3m-9 8.25h13.5A2.25 2.25 0 0021 18V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v12a2.25 2.25 0 002.25 2.25z" />
    </svg>
);

const CalendarIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>
    </svg>
);

const BoldIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M15.6 10.79c.97-.67 1.65-1.77 1.65-2.79 0-2.26-1.75-4-4-4H7v14h7.04c2.09 0 3.71-1.7 3.71-3.79 0-1.52-.86-2.82-2.15-3.42zM10 6.5h3c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-3v-3zm3.5 9H10v-3h3.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5z"></path></svg>;
const ItalicIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M10 4v3h2.21l-3.42 8H6v3h8v-3h-2.21l3.42-8H18V4z"></path></svg>;
const UnderlineIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12 17c3.31 0 6-2.69 6-6V3h-2.5v8c0 1.93-1.57 3.5-3.5 3.5S8.5 12.93 8.5 11V3H6v8c0 3.31 2.69 6 6 6zm-7 2v2h14v-2H5z"></path></svg>;
const AlignLeftIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M15 15H3v2h12v-2zm0-8H3v2h12V7zM3 13h18v-2H3v2zm0 8h18v-2H3v2zM3 3v2h18V3H3z"></path></svg>;
const AlignCenterIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M7 15v2h10v-2H7zm-4 6h18v-2H3v2zm0-8h18v-2H3v2zm4-6v2h10V7H7zM3 3v2h18V3H3z"></path></svg>;
const AlignRightIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M3 21h18v-2H3v2zm6-4h12v-2H9v2zm-6-4h18v-2H3v2zm6-4h12V7H9v2zM3 3v2h18V3H3z"></path></svg>;
const BulletListIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M11 17h10v-2H11v2zm-8-5h2V8H3v4zm0 5h2v-2H3v2zM3 4v2h2V4H3zm4 1h14V3H7v2zm0 6h14v-2H7v2zm0 6h14v-2H7v2z"></path></svg>;
const NumberedListIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M2 17h2v.5H3v1h1v.5H2v1h3v-4H2v1zm1-9h1V4H2v1h1v3zm-1 3h1.8L2 13.1v.9h3v-1H3.2L5 11.9V11H2v1zm5-6v2h14V5H7zm0 14h14v-2H7v2zm0-6h14v-2H7v2z"></path></svg>;
const ImageIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"></path></svg>;
const SidebarToggleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg>;
const AddNoteIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M14 10H3v2h11v-2zm0-4H3v2h11V6zm3 8v-2h-2v2h-2v2h2v2h2v-2h2v-2h-2zM3 16h7v-2H3v2z"></path></svg>;
const DeleteIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"></path></svg>;
const ColorIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"></path></svg>;
const PlayIcon = ({ className = "w-6 h-6" }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M8 5v14l11-7z"></path></svg>;
const PauseIcon = ({ className = "w-6 h-6" }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"></path></svg>;
const ResetIcon = ({ className = "w-6 h-6" }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"></path></svg>;
const LapIcon = ({ className = "w-6 h-6" }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 8V4H4v10h1v-4h5v4l3-3-3-3zm7 11h-6V8h6v11zm-1-6c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"></path></svg>;
export const AppearanceIcon = ({ className = "w-5 h-5" }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8v16z"></path></svg>;
export const BehaviorIcon = ({ className = "w-5 h-5" }: { className?: string }) => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M13.5 1.5c-2.22 0-4.27.9-5.83 2.34L6.22 5.29c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L9.1 5.25C10.24 4.22 11.81 3.5 13.5 3.5c2.73 0 5.05 1.89 5.8 4.5H15c-.55 0-1 .45-1 1s.45 1 1 1h5c.55 0 1-.45 1-1V3c0-.55-.45-1-1-1s-1 .45-1 1v1.44C18.66 3.2 16.27 1.5 13.5 1.5zM12 18.5c-3.14 0-5.87-2.03-6.68-4.88l-1.47.4c.98 3.43 4.14 6 7.65 6 2.22 0 4.27-.9 5.83-2.34l1.45-1.45c.39-.39.39-1.02 0-1.41-.39-.39-1.02-.39-1.41 0l-1.45 1.45c-1.14 1.03-2.71 1.75-4.4 1.75z"></path></svg>;
export const ControlCenterIcon = ({ className = "w-5 h-5" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75" />
    </svg>
);
const DownloadIcon = ({ className = "w-5 h-5" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);
export const ChatbotIcon = ({ className = "w-5 h-5" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 9.75a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375m-13.5 3.01c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.14 1.14 0 01.778-.332 48.294 48.294 0 005.83-.498c1.585-.233 2.708-1.626 2.708-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" />
    </svg>
);
const CalculatorIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 16H6V6h12v13z"/><path d="M9 8h2v2H9zm4 0h2v2h-2zm-4 4h2v2H9zm4 0h2v2h-2zM8 17h8v-2H8z"/>
    </svg>
);

const FileManagerIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M10 4H2v16h20V6H12l-2-2zM4 6h.83l1.58 1.58L7 9h13v9H4V6z"/>
    </svg>
);

const FileIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
    </svg>
);

const PlusIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
    </svg>
);

const BreadcrumbRightArrow = ({ className = "w-3 h-3" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
    </svg>
);

const BackIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6z" />
    </svg>
);

const ForwardIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"></path>
    </svg>
);

const UpIcon = ({ className = "w-6 h-6" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z" />
    </svg>
);

// --- App Components ---
interface Note {
  id: string;
  content: string;
}

// Helper function to extract title from HTML content
const getTitleFromContent = (htmlContent: string): string => {
    const doc = new DOMParser().parseFromString(htmlContent, 'text/html');
    const firstHeading = doc.querySelector('h1, h2, h3, h4, h5, h6');
    if (firstHeading && firstHeading.textContent) {
        return firstHeading.textContent.trim();
    }
    const firstParagraph = doc.querySelector('p');
    if (firstParagraph && firstParagraph.textContent) {
        return firstParagraph.textContent.trim();
    }
    const textContent = doc.body.textContent?.trim();
    return textContent ? textContent.substring(0, 50) + (textContent.length > 50 ? '...' : '') : 'Untitled Note';
};

// Helper function to extract a preview from HTML content
const getPreviewFromContent = (htmlContent: string): string => {
    const doc = new DOMParser().parseFromString(htmlContent, 'text/html');
    const textContent = doc.body.textContent?.trim();
    return textContent ? textContent.substring(0, 100) + (textContent.length > 100 ? '...' : '') : 'No content preview available.';
};

// Updated Notepad to work with FileSystem
interface NotepadProps {
    fileSystem: FileSystem;
    setFileSystem: React.Dispatch<React.SetStateAction<FileSystem>>;
    fileId?: string; // Optional fileId to open a specific file
}

const Notepad: React.FC<NotepadProps> = ({ fileSystem, setFileSystem, fileId }) => {
    const [notes, setNotes] = useState<Note[]>([]); // This will now be primarily derived from fileSystem
    const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
    const [isSidebarVisible, setIsSidebarVisible] = useState(true);
    const editorRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // FIX: Added explicit type annotation for 'node' in the filter callback
    // to resolve 'Property 'type' does not exist on type unknown' errors.
    const textFiles = Array.from(fileSystem.values()).filter((node: FileSystemNode): node is FileNode => node.type === 'file' && node.mimeType === 'text/plain');

    // Convert FileNodes to Notepad's internal Note format
    const convertedNotes = textFiles.map(file => ({
        id: file.id,
        content: file.content || 'Start writing your note here...',
    }));

    useEffect(() => {
        setNotes(convertedNotes);
        // If a fileId is provided, activate that file
        if (fileId && textFiles.some(f => f.id === fileId)) {
            setActiveNoteId(fileId);
        } else if (!activeNoteId && convertedNotes.length > 0) {
            setActiveNoteId(convertedNotes[0].id);
        } else if (activeNoteId && !textFiles.some(f => f.id === activeNoteId)) {
            setActiveNoteId(convertedNotes[0]?.id || null);
        }
    }, [fileSystem, fileId, activeNoteId, textFiles]); // Rerun effect when fileSystem or specific fileId changes

    const activeNote = notes.find(n => n.id === activeNoteId);

    useEffect(() => {
        if (editorRef.current && activeNote) {
            if (editorRef.current.innerHTML !== activeNote.content) {
                editorRef.current.innerHTML = activeNote.content;
            }
        }
    }, [activeNoteId, activeNote]);
    
    const updateNoteContent = (nodeId: string, newContent: string) => {
        setFileSystem(prev => {
            const newFs = new Map<string, FileSystemNode>(prev);
            const fileNode = newFs.get(nodeId);
            if (fileNode && fileNode.type === 'file' && fileNode.mimeType === 'text/plain') {
                newFs.set(nodeId, { ...fileNode, content: newContent });
            }
            return newFs;
        });
    };

    const handleEditorInput = () => {
        if (editorRef.current && activeNoteId) {
            updateNoteContent(activeNoteId, editorRef.current.innerHTML);
        }
    };

    const addNewNote = () => {
        const newId = `file-${Date.now()}`;
        const newFile: FileNode = {
            id: newId,
            name: `New Note ${textFiles.length + 1}.txt`,
            parentId: 'root-folder-id', // Default to root for simplicity, or add a default notes folder
            type: 'file',
            mimeType: 'text/plain',
            content: '<h1>New Note</h1>',
        };

        setFileSystem(prev => {
            const newFs = new Map<string, FileSystemNode>(prev);
            newFs.set(newId, newFile);
            const root = newFs.get('root-folder-id') as FolderNode; // Assuming root exists
            if (root) {
                newFs.set('root-folder-id', { ...root, childrenIds: [...root.childrenIds, newId] });
            }
            return newFs;
        });
        setActiveNoteId(newId);
        editorRef.current?.focus();
    };
    
    const deleteNote = (e: React.MouseEvent, noteId: string) => {
        e.stopPropagation();
        setFileSystem(prev => {
            const newFs = new Map<string, FileSystemNode>(prev);
            const nodeToDelete = newFs.get(noteId);
            if (nodeToDelete && nodeToDelete.parentId) {
                const parent = newFs.get(nodeToDelete.parentId) as FolderNode;
                if (parent) {
                  newFs.set(nodeToDelete.parentId, {
                      ...parent,
                      childrenIds: parent.childrenIds.filter(id => id !== noteId)
                  });
                }
            }
            newFs.delete(noteId);
            return newFs;
        });
        setNotes(prev => {
            const newNotes = prev.filter(n => n.id !== noteId);
            if (activeNoteId === noteId) {
                setActiveNoteId(newNotes[0]?.id || null);
            }
            return newNotes;
        });
    };
    
    const execCmd = (command: string, value?: string) => {
        document.execCommand(command, false, value);
        editorRef.current?.focus();
        // Trigger manual input handler to update state
        handleEditorInput();
    };

    const handleFontSizeChange = (e: React.SyntheticEvent<HTMLInputElement>) => {
        const size = e.currentTarget.value;
        if (!size) return;

        document.execCommand('fontSize', false, '1'); // Use a dummy value
        const fontElements = document.getElementsByTagName("font");
        for (let i = 0, len = fontElements.length; i < len; ++i) {
            if (fontElements[i].size == "1") {
                fontElements[i].removeAttribute("size");
                fontElements[i].style.fontSize = size + "px";
            }
        }
        editorRef.current?.focus();
        handleEditorInput();
    };
    
    const handleImageInsert = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            const imgData = event.target?.result;
            if (typeof imgData === 'string') {
                execCmd('insertHTML', `<img src="${imgData}" style="max-width: 100%; height: auto;" />`);
            }
        };
        reader.readAsDataURL(file);
    };

    const ToolbarButton: React.FC<{ onClick?: () => void; children: React.ReactNode; title: string }> = ({ onClick, children, title }) => (
        <button onClick={onClick} title={title} className="p-1.5 rounded hover:bg-black/10 dark:hover:bg-white/10">{children}</button>
    );

    return (
        <div className="flex h-full w-full bg-gray-100 dark:bg-gray-800 text-black dark:text-white">
            {isSidebarVisible && (
                <div className="w-64 h-full bg-gray-200 dark:bg-gray-900 flex flex-col border-r border-light-border dark:border-dark-border">
                    <div className="p-2 flex items-center justify-between border-b border-light-border dark:border-dark-border">
                        <button onClick={() => setIsSidebarVisible(false)} className="p-1.5 rounded hover:bg-black/10 dark:hover:bg-white/10"><SidebarToggleIcon /></button>
                        <h2 className="text-sm font-semibold">All Notes</h2>
                        <button onClick={addNewNote} className="p-1.5 rounded hover:bg-black/10 dark:hover:bg-white/10"><AddNoteIcon /></button>
                    </div>
                    <div className="flex-grow overflow-y-auto">
                        {notes.map(note => (
                            <div key={note.id} onClick={() => setActiveNoteId(note.id)} className={`p-2 cursor-pointer border-b border-light-border dark:border-dark-border group ${activeNoteId === note.id ? 'bg-primary/30' : 'hover:bg-black/5 dark:hover:bg-white/5'}`}>
                                <div className="flex justify-between items-start">
                                    <h3 className="font-semibold text-sm truncate">{getTitleFromContent(note.content)}</h3>
                                    <button onClick={(e) => deleteNote(e, note.id)} className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-500"><DeleteIcon /></button>
                                </div>
                                <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{getPreviewFromContent(note.content)}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            <div className="flex-grow flex flex-col relative">
                 {!isSidebarVisible && (
                    <button onClick={() => setIsSidebarVisible(true)} className="absolute top-1 left-1 z-10 p-1.5 rounded hover:bg-black/10 dark:hover:bg-white/10"><SidebarToggleIcon /></button>
                )}
                <div className="flex-shrink-0 p-1.5 flex items-center gap-1 border-b border-light-border dark:border-dark-border bg-gray-100 dark:bg-gray-800 flex-wrap">
                    <ToolbarButton onClick={() => execCmd('bold')} title="Bold"><BoldIcon /></ToolbarButton>
                    <ToolbarButton onClick={() => execCmd('italic')} title="Italic"><ItalicIcon /></ToolbarButton>
                    <ToolbarButton onClick={() => execCmd('underline')} title="Underline"><UnderlineIcon /></ToolbarButton>
                    <div className="w-px h-5 bg-gray-300 dark:bg-gray-600 mx-1"></div>
                    <ToolbarButton onClick={() => execCmd('justifyLeft')} title="Align Left"><AlignLeftIcon /></ToolbarButton>
                    <ToolbarButton onClick={() => execCmd('justifyCenter')} title="Align Center"><AlignCenterIcon /></ToolbarButton>
                    <ToolbarButton onClick={() => execCmd('justifyRight')} title="Align Right"><AlignRightIcon /></ToolbarButton>
                    <div className="w-px h-5 bg-gray-300 dark:bg-gray-600 mx-1"></div>
                    <ToolbarButton onClick={() => execCmd('insertUnorderedList')} title="Bulleted List"><BulletListIcon /></ToolbarButton>
                    <ToolbarButton onClick={() => execCmd('insertOrderedList')} title="Numbered List"><NumberedListIcon /></ToolbarButton>
                    <div className="w-px h-5 bg-gray-300 dark:bg-gray-600 mx-1"></div>
                    <ToolbarButton onClick={() => fileInputRef.current?.click()} title="Insert Image"><ImageIcon /></ToolbarButton>
                    <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageInsert} className="hidden" />
                    <div className="w-px h-5 bg-gray-300 dark:bg-gray-600 mx-1"></div>
                     <select onChange={(e) => execCmd('fontName', e.target.value)} className="bg-transparent text-sm p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 focus:outline-none appearance-none cursor-pointer">
                        <option value="Arial">Arial</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Verdana">Verdana</option>
                        <option value="Courier New">Courier New</option>
                    </select>
                    <input type="number" min="1" max="100" defaultValue="16" onChange={handleFontSizeChange} className="w-14 bg-transparent p-1 text-center rounded hover:bg-black/10 dark:hover:bg-white/10 focus:outline-none" title="Font Size (px)" />
                    <label title="Text Color" className="p-1.5 rounded hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer relative">
                        <ColorIcon />
                        <input type="color" onChange={(e) => execCmd('foreColor', e.target.value)} className="w-full h-full opacity-0 absolute top-0 left-0 cursor-pointer" />
                    </label>
                </div>
                <div 
                    ref={editorRef}
                    contentEditable
                    onInput={handleEditorInput}
                    className="flex-grow p-4 overflow-y-auto outline-none caret-black dark:caret-white"
                />
            </div>
        </div>
    );
};

// Updated Browser to work with FileSystem
interface BrowserProps {
  addDownloadedFile: (name: string, url: string, mimeType: string) => void;
  fileSystem: FileSystem; // Passed to Browser to inspect downloaded files
}

const Browser: React.FC<BrowserProps> = ({ addDownloadedFile, fileSystem }) => {
    const [url, setUrl] = useState('https://www.bing.com/search?q=LiquidOS');
    const [history, setHistory] = useState([url]);
    const [historyIndex, setHistoryIndex] = useState(0);
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [isDownloadsOpen, setIsDownloadsOpen] = useState(false);

    const downloadsFolder = fileSystem.get('downloads-folder-id') as FolderNode | undefined;
    const downloadedFiles = downloadsFolder ? downloadsFolder.childrenIds.map(id => fileSystem.get(id) as FileNode).filter((node): node is FileNode => node !== undefined) : [];

    const navigate = (newUrl: string) => {
        const fullUrl = newUrl.startsWith('http') ? newUrl : `https://www.bing.com/search?q=${encodeURIComponent(newUrl)}`;
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(fullUrl);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        setUrl(fullUrl);
    };
    
    const goBack = () => {
        if (historyIndex > 0) {
            setHistoryIndex(prev => prev - 1);
            setUrl(history[historyIndex - 1]);
        }
    }
    
    const goForward = () => {
        if (historyIndex < history.length - 1) {
            setHistoryIndex(prev => prev + 1);
            setUrl(history[historyIndex + 1]);
        }
    }
    
    const reload = () => {
        if (iframeRef.current) {
            iframeRef.current.src = 'about:blank';
            setTimeout(() => {
                if (iframeRef.current) iframeRef.current.src = url;
            }, 100);
        }
    };

    const downloadSampleEpub = () => {
        addDownloadedFile('Moby Dick.epub', 'https://s3.amazonaws.com/moby-dick/moby-dick.epub', 'application/epub+zip');
    };
    
    const downloadSamplePdf = () => {
        addDownloadedFile('React Cheat Sheet.pdf', 'https://periodic-table-of-html-elements.com/react-cheat-sheet.pdf', 'application/pdf');
    };

    return (
        <div className="h-full w-full bg-white dark:bg-gray-800 flex flex-col">
            <div className="flex-shrink-0 h-14 bg-gray-100 dark:bg-gray-900 flex items-center px-2 gap-2 border-b border-light-border dark:border-dark-border relative">
                <button onClick={goBack} disabled={historyIndex === 0} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-50"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg></button>
                <button onClick={goForward} disabled={historyIndex === history.length - 1} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-50"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg></button>
                <button onClick={reload} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5M20 4s0 0 0 0l-4 4M4 20s0 0 0 0l4-4" /></svg></button>
                <form onSubmit={(e) => { e.preventDefault(); navigate((e.currentTarget.elements.namedItem('url') as HTMLInputElement).value); }} className="flex-grow">
                    <input type="text" name="url" defaultValue={url} className="w-full h-9 px-4 rounded-full bg-white dark:bg-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
                </form>
                 <button onClick={downloadSampleEpub} title="Download Sample EPUB" className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10"><BookIcon className="w-5 h-5" /></button>
                 <button onClick={downloadSamplePdf} title="Download Sample PDF" className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10"><PDFIcon className="w-5 h-5" /></button>
                 <button onClick={() => setIsDownloadsOpen(o => !o)} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10"><DownloadIcon /></button>
            
                {isDownloadsOpen && (
                    <div className="absolute top-full right-0 mt-1 w-72 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-lg border border-light-border dark:border-dark-border shadow-2xl z-10 p-2">
                        <h3 className="font-semibold text-sm px-1 pb-1">Downloads</h3>
                        <div className="max-h-60 overflow-y-auto">
                            {downloadedFiles.length === 0 && <p className="text-xs text-gray-500 p-1">No downloads yet.</p>}
                            {downloadedFiles.map(file => (
                                <div key={file.id} className="flex items-center gap-2 p-1 rounded hover:bg-black/5 dark:hover:bg-white/5">
                                    {file.mimeType === 'application/epub+zip' ? <BookIcon className="w-5 h-5 flex-shrink-0" /> : <PDFIcon className="w-5 h-5 flex-shrink-0" />}
                                    <span className="text-sm truncate">{file.name}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            <iframe ref={iframeRef} src={url} className="flex-grow w-full h-full border-none" sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-presentation allow-same-origin allow-scripts" />
        </div>
    );
};

const useSound = (url: string) => {
    const audio = useRef<HTMLAudioElement | null>(null);
    useEffect(() => {
        audio.current = new Audio(url);
    }, [url]);
    return () => audio.current?.play();
};

const Clock: React.FC = () => {
    const [activeTab, setActiveTab] = useState('clock');
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        if (activeTab === 'clock') {
            const timerId = setInterval(() => setTime(new Date()), 1000);
            return () => clearInterval(timerId);
        }
    }, [activeTab]);

    const ClockDisplay = () => (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <h1 className="text-6xl md:text-8xl font-thin tracking-widest">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</h1>
            <p className="text-xl md:text-2xl mt-2">{time.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
    );

    const Stopwatch = () => {
        const [isActive, setIsActive] = useState(false);
        const [isPaused, setIsPaused] = useState(true);
        const [time, setTime] = useState(0);
        const [laps, setLaps] = useState<number[]>([]);

        useEffect(() => {
            let interval: any = null;
            if (isActive && !isPaused) {
                interval = setInterval(() => { setTime((time) => time + 10); }, 10);
            } else {
                clearInterval(interval);
            }
            return () => clearInterval(interval);
        }, [isActive, isPaused]);
        
        const formatTime = (time: number) => {
            const minutes = (`0` + Math.floor((time / 60000) % 60)).slice(-2);
            const seconds = (`0` + Math.floor((time / 1000) % 60)).slice(-2);
            const milliseconds = (`0` + ((time / 10) % 100)).slice(-2);
            return `${minutes}:${seconds}.${milliseconds}`;
        };

        return (
            <div className="flex flex-col h-full">
                <div className="flex-shrink-0 flex flex-col items-center justify-center py-8">
                    <p className="text-7xl font-mono">{formatTime(time)}</p>
                    <div className="flex gap-4 mt-6">
                        <button onClick={() => { setIsActive(true); setIsPaused(false); }} disabled={isActive && !isPaused} className="p-3 rounded-full bg-green-500/20 hover:bg-green-500/40 disabled:opacity-50"><PlayIcon /></button>
                        <button onClick={() => setIsPaused(true)} disabled={!isActive || isPaused} className="p-3 rounded-full bg-yellow-500/20 hover:bg-yellow-500/40 disabled:opacity-50"><PauseIcon /></button>
                        <button onClick={() => { setIsActive(false); setTime(0); setLaps([]); }} className="p-3 rounded-full bg-red-500/20 hover:bg-red-500/40"><ResetIcon /></button>
                        <button onClick={() => setLaps(laps => [...laps, time])} disabled={!isActive} className="p-3 rounded-full bg-blue-500/20 hover:bg-blue-500/40 disabled:opacity-50"><LapIcon /></button>
                    </div>
                </div>
                <div className="flex-grow overflow-y-auto px-4">
                    <ul className="divide-y divide-light-border dark:divide-dark-border">
                        {laps.map((lap, index) => (
                            <li key={index} className="py-2 flex justify-between font-mono text-lg">
                                <span>Lap {index + 1}</span>
                                <span>{formatTime(lap)}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        );
    };

    const Timer = () => {
        const [duration, setDuration] = useState(300); // 5 minutes
        const [timeLeft, setTimeLeft] = useState(duration);
        const [isActive, setIsActive] = useState(false);
        const playAlarm = useSound('https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg');
        
        useEffect(() => {
            if (!isActive || timeLeft <= 0) return;
            if (timeLeft === 1) playAlarm();

            const intervalId = setInterval(() => {
                setTimeLeft(timeLeft - 1);
            }, 1000);
            return () => clearInterval(intervalId);
        }, [isActive, timeLeft, playAlarm]);
        
        const formatTime = (seconds: number) => new Date(seconds * 1000).toISOString().substr(11, 8);
        const handleSetTime = (val: number) => { if(!isActive) { setDuration(val); setTimeLeft(val); } };

        return (
            <div className="flex flex-col items-center justify-center h-full">
                <div className="text-8xl font-mono">{formatTime(timeLeft)}</div>
                {!isActive && (
                    <div className="flex gap-2 my-4">
                         <button onClick={() => handleSetTime(60)} className="px-3 py-1 text-sm rounded-full bg-white/10 hover:bg-white/20">1 min</button>
                         <button onClick={() => handleSetTime(300)} className="px-3 py-1 text-sm rounded-full bg-white/10 hover:bg-white/20">5 min</button>
                         <button onClick={() => handleSetTime(600)} className="px-3 py-1 text-sm rounded-full bg-white/10 hover:bg-white/20">10 min</button>
                    </div>
                )}
                <div className="flex gap-4 mt-6">
                    <button onClick={() => setIsActive(true)} disabled={isActive} className="p-3 rounded-full bg-green-500/20 hover:bg-green-500/40 disabled:opacity-50"><PlayIcon /></button>
                    <button onClick={() => setIsActive(false)} disabled={!isActive} className="p-3 rounded-full bg-yellow-500/20 hover:bg-yellow-500/40 disabled:opacity-50"><PauseIcon /></button>
                    <button onClick={() => { setIsActive(false); setTimeLeft(duration); }} className="p-3 rounded-full bg-red-500/20 hover:bg-red-500/40"><ResetIcon /></button>
                </div>
            </div>
        );
    };
    
    const TabButton = ({ id, label }: { id: string, label: string }) => (
        <button onClick={() => setActiveTab(id)} className={`px-4 py-2 text-sm font-medium ${activeTab === id ? 'border-b-2 border-primary text-primary' : 'text-gray-500 hover:text-primary'}`}>
            {label}
        </button>
    );

    return (
        <div className="h-full w-full bg-gray-100 dark:bg-gray-800 text-black dark:text-white flex flex-col">
            <div className="flex-shrink-0 border-b border-light-border dark:border-dark-border flex justify-center">
                <TabButton id="clock" label="World Clock" />
                <TabButton id="stopwatch" label="Stopwatch" />
                <TabButton id="timer" label="Timer" />
            </div>
            <div className="flex-grow">
                {activeTab === 'clock' && <ClockDisplay />}
                {activeTab === 'stopwatch' && <Stopwatch />}
                {activeTab === 'timer' && <Timer />}
            </div>
        </div>
    );
};

// --- Calendar App Component ---
// Reminders type is already in types.ts

const Calendar: React.FC = () => {
    const [currentDate, setCurrentDate] = useState(new Date()); // Tracks the month being viewed
    const [reminders, setReminders] = useState<Reminders>({});
    const [selectedDateForReminder, setSelectedDateForReminder] = useState<string | null>(null);
    const [newReminderText, setNewReminderText] = useState('');
    const reminderInputRef = useRef<HTMLInputElement>(null);

    const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay(); // 0 = Sunday, 1 = Monday, etc.

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth(); // 0-indexed

    const totalDays = daysInMonth(year, month);
    const startDay = firstDayOfMonth(year, month);
    const prevMonthDays = daysInMonth(year, month - 1);

    const today = new Date();
    const isToday = (day: number, currentMonth: number, currentYear: number) =>
        day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
    
    const formatFullDate = (year: number, month: number, day: number) => {
        const d = new Date(year, month, day);
        return d.toISOString().split('T')[0]; // YYYY-MM-DD
    };

    const addReminder = () => {
        if (selectedDateForReminder && newReminderText.trim()) {
            setReminders(prev => ({
                ...prev,
                [selectedDateForReminder]: [...(prev[selectedDateForReminder] || []), newReminderText.trim()]
            }));
            setNewReminderText('');
            setSelectedDateForReminder(null); // Close reminder input
        }
    };

    const deleteReminder = (dateString: string, reminderIndex: number) => {
        setReminders(prev => {
            const newDateReminders = (prev[dateString] || []).filter((_, i) => i !== reminderIndex);
            if (newDateReminders.length === 0) {
                const newState = { ...prev };
                delete newState[dateString];
                return newState;
            }
            return {
                ...prev,
                [dateString]: newDateReminders
            };
        });
    };

    const handleDayClick = (day: number, monthOffset: number = 0) => {
        const clickedMonth = new Date(year, month + monthOffset, day);
        const dateString = formatFullDate(clickedMonth.getFullYear(), clickedMonth.getMonth(), clickedMonth.getDate());
        setSelectedDateForReminder(dateString);
        setNewReminderText('');
        // Focus the input if it's already rendered, otherwise it will focus on next render
        setTimeout(() => reminderInputRef.current?.focus(), 0);
    };

    const renderDay = (day: number, isCurrentMonth: boolean, dayIndex: number) => {
        const dateString = formatFullDate(year, month, day);
        const dayReminders = reminders[dateString] || [];
        const isSelected = selectedDateForReminder === dateString;

        return (
            <div 
                key={`${year}-${month}-${day}-${dayIndex}`}
                className={`relative p-1 h-24 flex flex-col border border-light-border dark:border-dark-border text-sm overflow-hidden 
                            ${isCurrentMonth ? 'bg-white/5 dark:bg-black/5' : 'bg-gray-100/5 dark:bg-gray-900/5 text-gray-400'}
                            ${isToday(day, month, year) && isCurrentMonth ? 'bg-primary/20 ring-2 ring-primary' : ''}
                            ${isSelected ? 'ring-2 ring-blue-500' : ''}
                            hover:bg-primary/10 cursor-pointer transition-colors duration-100 ease-in-out`}
                onClick={() => handleDayClick(day)}
            >
                <div className="font-semibold">{day}</div>
                <div className="flex flex-col gap-0.5 mt-1 overflow-y-auto custom-scrollbar">
                    {dayReminders.map((reminder, index) => (
                        <div key={index} className="flex items-center justify-between bg-primary/80 text-white text-xs px-1 rounded truncate group hover:bg-red-500">
                            <span className="truncate">{reminder}</span>
                            <button 
                                onClick={(e) => { e.stopPropagation(); deleteReminder(dateString, index); }} 
                                className="ml-1 text-white/80 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                                title="Delete reminder"
                            >
                                x
                            </button>
                        </div>
                    ))}
                </div>
                {isSelected && (
                    <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-light-bg/90 dark:bg-dark-bg/90 p-2 border-2 border-blue-500 rounded-lg shadow-lg">
                        <input
                            ref={reminderInputRef}
                            type="text"
                            placeholder="Add reminder..."
                            className="w-full text-xs p-1 rounded bg-white dark:bg-gray-700 text-black dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                            value={newReminderText}
                            onChange={(e) => setNewReminderText(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') addReminder(); }}
                        />
                        <div className="flex gap-1 mt-1">
                            <button onClick={addReminder} className="px-2 py-0.5 text-xs bg-primary text-white rounded hover:bg-primary/90">Add</button>
                            <button onClick={() => setSelectedDateForReminder(null)} className="px-2 py-0.5 text-xs bg-gray-300 text-black rounded hover:bg-gray-400 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600">Cancel</button>
                        </div>
                    </div>
                )}
            </div>
        );
    };

    const days = [];
    // Previous month's days
    for (let i = 0; i < startDay; i++) {
        days.push(renderDay(prevMonthDays - startDay + 1 + i, false, i));
    }
    // Current month's days
    for (let i = 1; i <= totalDays; i++) {
        days.push(renderDay(i, true, startDay + i -1));
    }
    // Next month's days
    const remainingCells = 42 - days.length; // 6 rows * 7 days
    for (let i = 1; i <= remainingCells; i++) {
        days.push(renderDay(i, false, startDay + totalDays + i -1));
    }

    return (
        <div className="h-full w-full bg-gray-100 dark:bg-gray-800 text-black dark:text-white flex flex-col">
            <div className="flex-shrink-0 p-3 flex items-center justify-between border-b border-light-border dark:border-dark-border">
                <button 
                    onClick={() => setCurrentDate(new Date(year, month - 1, 1))} 
                    className="p-2 rounded-md hover:bg-black/10 dark:hover:bg-white/10"
                    title="Previous Month"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg>
                </button>
                <h2 className="text-lg font-semibold">
                    {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </h2>
                <button 
                    onClick={() => setCurrentDate(new Date(year, month + 1, 1))} 
                    className="p-2 rounded-md hover:bg-black/10 dark:hover:bg-white/10"
                    title="Next Month"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"></path></svg>
                </button>
            </div>
            <div className="grid grid-cols-7 flex-shrink-0 text-center text-sm font-medium border-b border-light-border dark:border-dark-border">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="py-2">{day}</div>
                ))}
            </div>
            <div className="grid grid-cols-7 flex-grow">
                {days}
            </div>
        </div>
    );
};

// Updated LiquidOSBookReader to work with FileSystem
interface LiquidOSBookReaderProps {
  fileSystem: FileSystem;
  fileId?: string; // Optional fileId to open a specific book
}

const LiquidOSBookReader: React.FC<LiquidOSBookReaderProps> = ({ fileSystem, fileId }) => {
    const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
    const bookContainerRef = useRef<HTMLDivElement>(null);
    const rendition = useRef<any>(null);
    const [isLoading, setIsLoading] = useState(false);
    
    // Filter book files from the fileSystem
    const books = Array.from(fileSystem.values()).filter((f: FileSystemNode): f is FileNode => f.type === 'file' && (f.mimeType === 'application/epub+zip' || f.mimeType === 'application/pdf'));

    // Effect to handle opening a specific file or default to the first available book
    useEffect(() => {
        if (fileId) {
            const fileToOpen = fileSystem.get(fileId) as FileNode | undefined;
            // FIX: Removed redundant type assertion. TypeScript's control flow analysis will correctly handle `fileToOpen.type` and `fileToOpen.mimeType`.
            if (fileToOpen && fileToOpen.type === 'file' && (fileToOpen.mimeType === 'application/epub+zip' || fileToOpen.mimeType === 'application/pdf')) {
                openBook(fileToOpen);
            }
        } else if (!selectedFile && books.length > 0) {
            // Automatically open the first book if no specific fileId and nothing is selected
            openBook(books[0]);
        }
    }, [fileId, fileSystem, selectedFile, books]); // Re-run when fileId or fileSystem changes

    const openBook = async (file: FileNode) => {
        setSelectedFile(file);
        // FIX: Removed redundant type assertion. `file` is already typed as `FileNode`.
        if (file.type === 'file' && file.mimeType === 'application/epub+zip' && bookContainerRef.current) {
            setIsLoading(true);
            try {
                const response = await fetch(file.url!);
                const bookData = await response.arrayBuffer();

                bookContainerRef.current.innerHTML = '';
                const book = ePub(bookData);
                rendition.current = book.renderTo(bookContainerRef.current, {
                    width: "100%",
                    height: "100%",
                    flow: "paginated",
                    spread: "auto"
                });
                await rendition.current.display();
            } catch (error) {
                console.error("Error opening EPUB file:", error);
                if (bookContainerRef.current) {
                    bookContainerRef.current.innerHTML = '<div class="p-4 text-red-500">Error loading book. It might be a CORS issue or an invalid file.</div>';
                }
            } finally {
                setIsLoading(false);
            }
        }
    };
    
    if (selectedFile) {
        return (
            <div className="h-full w-full bg-gray-100 dark:bg-gray-800 flex flex-col">
                <div className="flex-shrink-0 h-10 bg-gray-200 dark:bg-gray-900 flex items-center px-2 justify-between">
                    <button onClick={() => setSelectedFile(null)} className="px-2 py-1 text-sm rounded hover:bg-black/10 dark:hover:bg-white/10">← Back to Library</button>
                    <span className="text-sm font-semibold truncate">{selectedFile.name}</span>
                    <div className="flex gap-1">
                        {selectedFile.mimeType === 'application/epub+zip' && rendition.current && (
                            <>
                            <button onClick={() => rendition.current.prev()} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10">‹</button>
                            <button onClick={() => rendition.current.next()} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10">›</button>
                            </>
                        )}
                    </div>
                </div>
                <div className="flex-grow relative">
                    {isLoading && <div className="absolute inset-0 flex items-center justify-center">Loading book...</div>}
                    {selectedFile.mimeType === 'application/epub+zip' && <div ref={bookContainerRef} className="h-full w-full" />}
                    {selectedFile.mimeType === 'application/pdf' && <iframe src={selectedFile.url} className="h-full w-full border-none" />}
                </div>
            </div>
        );
    }
    
    return (
        <div className="h-full w-full bg-gray-100 dark:bg-gray-800 p-4">
            <h2 className="text-2xl font-bold mb-4">Your Library</h2>
            {books.length === 0 ? (
                <p>Your library is empty. Download some books from the browser or add them via File Manager!</p>
            ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
                    {books.map(book => (
                        <div key={book.id} onClick={() => openBook(book)} className="flex flex-col items-center p-2 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer">
                            <div className="w-20 h-28 flex items-center justify-center bg-gray-200 dark:bg-gray-700 rounded-md">
                                {book.mimeType === 'application/epub+zip' ? <BookIcon className="w-12 h-12" /> : <PDFIcon className="w-12 h-12" />}
                            </div>
                            <span className="text-xs text-center mt-2 truncate w-full">{book.name}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const OneCompiler: React.FC = () => {
    return (
        <div className="h-full w-full bg-white">
            <iframe
                src="https://onecompiler.com"
                className="w-full h-full border-none"
                title="OneCompiler"
                sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-presentation allow-same-origin allow-scripts"
            ></iframe>
        </div>
    );
};

const Calculator: React.FC = () => {
    const [display, setDisplay] = useState('0');
    const [operator, setOperator] = useState<string | null>(null);
    const [prevValue, setPrevValue] = useState<string | null>(null);
    const [waitingForNewInput, setWaitingForNewInput] = useState(false);

    const handleDigit = (digit: string) => {
        if (waitingForNewInput) {
            setDisplay(digit);
            setWaitingForNewInput(false);
        } else {
            setDisplay(display === '0' ? digit : display + digit);
        }
    };

    const handleDecimal = () => {
        if (waitingForNewInput) {
            setDisplay('0.');
            setWaitingForNewInput(false);
        } else if (!display.includes('.')) {
            setDisplay(display + '.');
        }
    };

    const handleOperator = (nextOperator: string) => {
        const inputValue = parseFloat(display);

        if (prevValue === null) {
            setPrevValue(display);
        } else if (operator) {
            const currentValue = parseFloat(prevValue);
            let newValue = 0;
            switch (operator) {
                case '+':
                    newValue = currentValue + inputValue;
                    break;
                case '-':
                    newValue = currentValue - inputValue;
                    break;
                case '*':
                    newValue = currentValue * inputValue;
                    break;
                case '/':
                    newValue = currentValue / inputValue;
                    break;
                default:
                    break;
            }
            setPrevValue(String(newValue));
            setDisplay(String(newValue));
        }

        setWaitingForNewInput(true);
        setOperator(nextOperator);
    };

    const handleEquals = () => {
        const inputValue = parseFloat(display);
        const currentValue = parseFloat(prevValue || '0');
        let newValue = 0;

        if (operator) {
            switch (operator) {
                case '+':
                    newValue = currentValue + inputValue;
                    break;
                case '-':
                    newValue = currentValue - inputValue;
                    break;
                case '*':
                    newValue = currentValue * inputValue;
                    break;
                case '/':
                    newValue = currentValue / inputValue;
                    break;
                default:
                    break;
            }
            setDisplay(String(newValue));
            setPrevValue(null);
            setOperator(null);
            setWaitingForNewInput(true);
        }
    };

    const handleClear = () => {
        setDisplay('0');
        setOperator(null);
        setPrevValue(null);
        setWaitingForNewInput(false);
    };

    const CalculatorButton: React.FC<{ onClick: () => void; label: string; className?: string }> = ({ onClick, label, className }) => (
        <button onClick={onClick} className={`flex items-center justify-center p-4 rounded-lg text-2xl font-semibold bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 ${className}`}>
            {label}
        </button>
    );

    return (
        <div className="h-full w-full bg-gray-100 dark:bg-gray-900 flex flex-col p-4 text-black dark:text-white">
            <div className="flex-grow flex flex-col justify-end items-end p-2 mb-4 bg-gray-200 dark:bg-gray-800 rounded-lg overflow-hidden">
                <div className="text-5xl font-thin break-all text-right">
                    {display}
                </div>
            </div>
            <div className="grid grid-cols-4 gap-3 flex-shrink-0">
                <CalculatorButton onClick={handleClear} label="C" className="col-span-2 bg-red-400 hover:bg-red-500 dark:bg-red-700 dark:hover:bg-red-600 text-white" />
                <CalculatorButton onClick={() => handleOperator('/')} label="/" className="bg-primary/80 hover:bg-primary text-white" />
                <CalculatorButton onClick={() => handleOperator('*')} label="x" className="bg-primary/80 hover:bg-primary text-white" />
                
                <CalculatorButton onClick={() => handleDigit('7')} label="7" />
                <CalculatorButton onClick={() => handleDigit('8')} label="8" />
                <CalculatorButton onClick={() => handleDigit('9')} label="9" />
                <CalculatorButton onClick={() => handleOperator('-')} label="-" className="bg-primary/80 hover:bg-primary text-white" />

                <CalculatorButton onClick={() => handleDigit('4')} label="4" />
                <CalculatorButton onClick={() => handleDigit('5')} label="5" />
                <CalculatorButton onClick={() => handleDigit('6')} label="6" />
                <CalculatorButton onClick={() => handleOperator('+')} label="+" className="bg-primary/80 hover:bg-primary text-white" />

                <CalculatorButton onClick={() => handleDigit('1')} label="1" />
                <CalculatorButton onClick={() => handleDigit('2')} label="2" />
                <CalculatorButton onClick={() => handleDigit('3')} label="3" />
                <CalculatorButton onClick={handleEquals} label="=" className="row-span-2 bg-green-500 hover:bg-green-600 dark:bg-green-700 dark:hover:bg-green-600 text-white" />

                <CalculatorButton onClick={() => handleDigit('0')} label="0" className="col-span-2" />
                <CalculatorButton onClick={handleDecimal} label="." />
            </div>
        </div>
    );
};


// --- File Manager App Component ---
interface FileManagerProps {
  fileSystem: FileSystem;
  setFileSystem: React.Dispatch<React.SetStateAction<FileSystem>>;
  rootFolderId: string;
  openApp: (appId: string, fileId?: string) => void;
}

const FileManager: React.FC<FileManagerProps> = ({ fileSystem, setFileSystem, rootFolderId, openApp }) => {
  const [currentFolderId, setCurrentFolderId] = useState<string>(rootFolderId);
  const [newFolderName, setNewFolderName] = useState('');
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; nodeId: string } | null>(null);
  const [renamingNodeId, setRenamingNodeId] = useState<string | null>(null);
  const [renameInput, setRenameInput] = useState('');
  const renameInputRef = useRef<HTMLInputElement>(null);

  const currentFolder = fileSystem.get(currentFolderId) as FolderNode;
  const childrenNodes = currentFolder?.childrenIds
    .map(id => fileSystem.get(id))
    .filter((node): node is FileSystemNode => node !== undefined)
    .sort((a, b) => {
      // Sort folders first, then files, then alphabetically
      if (a.type === 'folder' && b.type !== 'folder') return -1;
      if (a.type !== 'folder' && b.type === 'folder') return 1;
      return a.name.localeCompare(b.name);
    });

  const generateId = useCallback((prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`, []);

  const navigateToFolder = (folderId: string) => {
    const targetNode = fileSystem.get(folderId);
    if (targetNode && targetNode.type === 'folder') {
      setCurrentFolderId(folderId);
      setContextMenu(null); // Close context menu on navigation
    }
  };

  const navigateUp = () => {
    // FIX: Removed redundant type assertion. TypeScript infers `node.parentId` after `node` is accessed from `fileSystem`.
    const node = fileSystem.get(currentFolderId) as FileSystemNode | undefined;
    const parentId = node?.parentId;
    if (parentId) {
      setCurrentFolderId(parentId);
      setContextMenu(null);
    }
  };

  const createNewFolder = () => {
    if (!newFolderName.trim()) return;

    const newId = generateId('folder');
    const newFolder: FolderNode = {
      id: newId,
      name: newFolderName.trim(),
      parentId: currentFolderId,
      type: 'folder',
      childrenIds: [],
    };

    setFileSystem(prev => {
      const newFs = new Map<string, FileSystemNode>(prev);
      newFs.set(newId, newFolder);
      const parent = newFs.get(currentFolderId) as FolderNode;
      if (parent) { // Ensure parent exists
          newFs.set(currentFolderId, { ...parent, childrenIds: [...parent.childrenIds, newId] });
      }
      return newFs;
    });
    setNewFolderName('');
  };

  const deleteNode = (nodeId: string) => {
    setFileSystem(prev => {
      const newFs = new Map<string, FileSystemNode>(prev);
      const nodeToDelete = newFs.get(nodeId);
      if (!nodeToDelete) return prev;

      // Remove from parent's childrenIds
      // FIX: Removed redundant type assertion. TypeScript correctly infers `nodeToDelete.parentId`.
      if (nodeToDelete.parentId) {
        const parent = newFs.get(nodeToDelete.parentId) as FolderNode;
        if (parent) {
            newFs.set(nodeToDelete.parentId, {
                ...parent,
                childrenIds: parent.childrenIds.filter(id => id !== nodeId)
            });
        }
      }

      // Recursively delete children if it's a folder
      // FIX: Removed redundant type assertion. TypeScript correctly infers `nodeToDelete.type`.
      if (nodeToDelete.type === 'folder') {
        const queue: string[] = [...nodeToDelete.childrenIds];
        while (queue.length > 0) {
          const childId = queue.shift()!;
          const childNode = newFs.get(childId);
          // FIX: Removed redundant type assertion. TypeScript correctly infers `childNode.type`.
          if (childNode?.type === 'folder') {
            queue.push(...(childNode as FolderNode).childrenIds);
          }
          newFs.delete(childId);
        }
      }
      newFs.delete(nodeId);
      return newFs;
    });
    setContextMenu(null);
  };

  const startRename = (nodeId: string, currentName: string) => {
    setRenamingNodeId(nodeId);
    setRenameInput(currentName);
    setContextMenu(null);
    // Focus the input after it renders
    setTimeout(() => renameInputRef.current?.focus(), 0);
  };

  const handleRename = (nodeId: string, newName: string) => {
    if (!newName.trim() || newName.trim() === (fileSystem.get(nodeId)?.name || '')) {
        setRenamingNodeId(null);
        setRenameInput('');
        return;
    }
    setFileSystem(prev => {
      const newFs = new Map<string, FileSystemNode>(prev);
      const node = newFs.get(nodeId);
      if (node) {
        // FIX: Removed redundant type assertion. TypeScript correctly infers `node.name` as `FileSystemNode` has a `name` property.
        newFs.set(nodeId, { ...node, name: newName.trim() });
      }
      return newFs;
    });
    setRenamingNodeId(null);
    setRenameInput('');
  };

  const handleOpenFile = (node: FileNode) => {
    let appId: string | null = null;
    switch (node.mimeType) {
      case 'text/plain':
        appId = 'notepad';
        break;
      case 'image/jpeg':
      case 'image/png':
        // No dedicated image viewer, could open in browser if it's a URL
        // For now, let's just log this or inform the user
        console.warn(`No dedicated app for images yet. File: ${node.name}`);
        alert(`Cannot open "${node.name}". No dedicated image viewer app yet. You can open it manually with the browser if it's a web URL.`);
        return;
      case 'application/pdf':
      case 'application/epub+zip':
        appId = 'liquid-book-reader';
        break;
      default:
        console.warn(`No default app for mimeType: ${node.mimeType}`);
        alert(`Cannot open "${node.name}". No default application found for this file type.`);
        return;
    }
    if (appId) {
      openApp(appId, node.id); // Pass fileId to the openApp function
    }
  };

  const FileItem: React.FC<{ node: FileSystemNode }> = ({ node }) => {
    const handleDoubleClick = () => {
      // FIX: Removed redundant type assertion for `node.type`. `node` is already typed as `FileSystemNode`.
      if (node.type === 'folder') {
        navigateToFolder(node.id);
      } else {
        handleOpenFile(node as FileNode); // Cast to FileNode for handleOpenFile
      }
    };

    const handleContextMenu = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation(); // Prevent document-wide context menu if clicked on item
      setContextMenu({ x: e.clientX, y: e.clientY, nodeId: node.id });
    };

    // FIX: Removed redundant type assertion for `node.type`. `node` is already typed as `FileSystemNode`.
    const icon = node.type === 'folder' ? <FolderIcon className="w-10 h-10" /> : getFileIcon(node as FileNode);

    return (
      <div
        className="flex flex-col items-center w-24 p-2 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer text-center relative group"
        onDoubleClick={handleDoubleClick}
        onContextMenu={handleContextMenu}
        title={node.name}
      >
        <div className="w-10 h-10 mb-1 drop-shadow-lg">{icon}</div>
        {renamingNodeId === node.id ? (
          <input
            ref={renameInputRef}
            type="text"
            value={renameInput}
            onChange={(e) => setRenameInput(e.target.value)}
            onBlur={() => handleRename(node.id, renameInput)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleRename(node.id, renameInput); }}
            className="w-full text-xs bg-gray-200 dark:bg-gray-700 text-black dark:text-white px-1 py-0.5 rounded focus:outline-none"
            autoFocus
          />
        ) : (
          <span className="text-xs truncate w-full">{node.name}</span>
        )}
      </div>
    );
  };
  
  const getFileIcon = (file: FileNode) => {
    // FIX: Removed redundant type assertion for `file.mimeType`. `file` is already typed as `FileNode`.
    switch (file.mimeType) {
      case 'text/plain': return <NoteIcon className="w-10 h-10" />;
      case 'image/jpeg':
      case 'image/png': return <ImageIcon className="w-10 h-10" />;
      case 'application/pdf': return <PDFIcon className="w-10 h-10" />;
      case 'application/epub+zip': return <BookIcon className="w-10 h-10" />;
      default: return <FileIcon className="w-10 h-10" />; // Generic file icon
    }
  };

  const getBreadcrumbs = () => {
    let path: { id: string, name: string }[] = [];
    let current: FileSystemNode | undefined = fileSystem.get(currentFolderId);
    while (current) {
      path.unshift({ id: current.id, name: current.name });
      current = current.parentId ? fileSystem.get(current.parentId) : undefined;
    }
    if (path.length > 0 && path[0].name === 'root') {
        path[0].name = 'Home';
    }
    return path;
  };
  const breadcrumbs = getBreadcrumbs();

  const closeContextMenu = () => setContextMenu(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (contextMenu && !(event.target as HTMLElement).closest('.context-menu')) {
            closeContextMenu();
        }
        if (renamingNodeId && renameInputRef.current && !renameInputRef.current.contains(event.target as Node)) {
            handleRename(renamingNodeId, renameInput);
        }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, [contextMenu, renamingNodeId, renameInput, handleRename]);


  return (
    <div className="h-full w-full bg-gray-100 dark:bg-gray-800 text-black dark:text-white flex flex-col">
      <div className="flex-shrink-0 p-3 flex items-center gap-2 border-b border-light-border dark:border-dark-border">
        <button onClick={navigateUp} disabled={currentFolderId === rootFolderId} className="p-1.5 rounded-md hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-50" title="Up">
            <UpIcon className="w-5 h-5" />
        </button>
        {/* Could add back/forward with history stack */}
        <div className="flex items-center gap-1 flex-grow overflow-x-auto whitespace-nowrap custom-scrollbar">
            {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={crumb.id}>
                    <button onClick={() => navigateToFolder(crumb.id)} className="px-2 py-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 text-sm font-medium">
                        {crumb.name}
                    </button>
                    {index < breadcrumbs.length - 1 && <BreadcrumbRightArrow />}
                </React.Fragment>
            ))}
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <input
            type="text"
            placeholder="New folder name"
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') createNewFolder(); }}
            className="w-36 text-sm p-1 rounded bg-white dark:bg-gray-700 text-black dark:text-white focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <button onClick={createNewFolder} className="p-1.5 rounded-md bg-primary hover:bg-primary/90 text-white" title="Create New Folder">
            <PlusIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="flex-grow p-4 overflow-y-auto custom-scrollbar">
        {childrenNodes.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400 text-center mt-8">This folder is empty.</p>
        ) : (
          <div className="grid grid-cols-fill-24 gap-4"> {/* Custom utility class for responsive grid */}
            {childrenNodes.map(node => (
              <FileItem key={node.id} node={node} />
            ))}
          </div>
        )}
      </div>

      {contextMenu && (
        <div
          style={{ top: contextMenu.y, left: contextMenu.x }}
          className="context-menu absolute z-50 w-48 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-xl rounded-lg shadow-2xl border border-light-border dark:border-dark-border p-1 text-black dark:text-white"
        >
          {contextMenu.nodeId && fileSystem.get(contextMenu.nodeId)?.type === 'file' && (
              <div onClick={() => { handleOpenFile(fileSystem.get(contextMenu.nodeId) as FileNode); closeContextMenu(); }} className="px-3 py-1.5 text-sm rounded-md hover:bg-primary hover:text-white cursor-pointer transition-colors">
                Open
              </div>
          )}
          <div onClick={() => startRename(contextMenu.nodeId, fileSystem.get(contextMenu.nodeId)?.name || '')} className="px-3 py-1.5 text-sm rounded-md hover:bg-primary hover:text-white cursor-pointer transition-colors">
            Rename
          </div>
          <div onClick={() => deleteNode(contextMenu.nodeId)} className="px-3 py-1.5 text-sm rounded-md hover:bg-red-500 hover:text-white cursor-pointer transition-colors">
            Delete
          </div>
        </div>
      )}
    </div>
  );
};

// Placeholder for Settings component
interface SettingsProps {
    isDarkMode: boolean;
    setIsDarkMode: (value: boolean) => void;
    clickBehavior: 'single' | 'double';
    setClickBehavior: (value: 'single' | 'double') => void;
}

const Settings: React.FC<SettingsProps> = ({ isDarkMode, setIsDarkMode, clickBehavior, setClickBehavior }) => {
    return (
        <div className="h-full w-full bg-gray-100 dark:bg-gray-800 text-black dark:text-white p-4 flex flex-col gap-4">
            <h2 className="text-xl font-bold">Settings</h2>
            <div className="flex items-center justify-between p-2 rounded-md bg-gray-200 dark:bg-gray-700">
                <div className="flex items-center gap-3">
                  <AppearanceIcon className="w-5 h-5"/>
                  <span className="text-sm">Theme</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-xs">Light</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" checked={isDarkMode} onChange={() => setIsDarkMode(!isDarkMode)} className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-300 rounded-full peer peer-focus:ring-2 peer-focus:ring-primary dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                    </label>
                    <span className="text-xs">Dark</span>
                </div>
            </div>
            <div className="flex items-center justify-between p-2 rounded-md bg-gray-200 dark:bg-gray-700">
                <div className="flex items-center gap-3">
                  <BehaviorIcon className="w-5 h-5"/>
                  <span className="text-sm">Desktop Icon Click Behavior</span>
                </div>
                <div className="flex items-center gap-2">
                    <label className="inline-flex items-center">
                        <input 
                            type="radio" 
                            name="clickBehavior" 
                            value="single" 
                            checked={clickBehavior === 'single'} 
                            onChange={() => setClickBehavior('single')} 
                            className="form-radio text-primary" 
                        />
                        <span className="ml-2 text-sm">Single Click</span>
                    </label>
                    <label className="inline-flex items-center ml-4">
                        <input 
                            type="radio" 
                            name="clickBehavior" 
                            value="double" 
                            checked={clickBehavior === 'double'} 
                            onChange={() => setClickBehavior('double')} 
                            className="form-radio text-primary" 
                        />
                        <span className="ml-2 text-sm">Double Click</span>
                    </label>
                </div>
            </div>
        </div>
    );
};

// Placeholder for Terminal component
const Terminal: React.FC = () => {
    const [output, setOutput] = useState<string[]>(['Welcome to LiquidOS Terminal.']);
    const [input, setInput] = useState('');
    const terminalRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        terminalRef.current?.scrollTo(0, terminalRef.current.scrollHeight);
    }, [output]);

    const handleCommand = (command: string) => {
        const newOutput = [...output, `> ${command}`];
        const lowerCommand = command.toLowerCase().trim();

        if (lowerCommand === 'help') {
            newOutput.push('Available commands: help, echo [text], clear, date, whoami');
        } else if (lowerCommand.startsWith('echo ')) {
            newOutput.push(command.substring(5));
        } else if (lowerCommand === 'clear') {
            newOutput.splice(0, newOutput.length); // Clear all previous output
        } else if (lowerCommand === 'date') {
            newOutput.push(new Date().toLocaleString());
        } else if (lowerCommand === 'whoami') {
            newOutput.push('user@liquid-os');
        }
        else {
            newOutput.push(`Command not found: ${command}`);
        }
        setOutput(newOutput);
        setInput('');
    };

    return (
        <div className="h-full w-full bg-black text-green-400 p-4 flex flex-col font-mono text-sm">
            <div ref={terminalRef} className="flex-grow overflow-y-auto custom-scrollbar pr-2">
                {output.map((line, index) => (
                    <div key={index}>{line}</div>
                ))}
            </div>
            <div className="flex-shrink-0 flex items-center mt-2">
                <span className="mr-2">&gt;</span>
                <input
                    type="text"
                    className="flex-grow bg-transparent border-none outline-none text-green-400 caret-green-400"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                            handleCommand(input);
                        }
                    }}
                    autoFocus
                />
            </div>
        </div>
    );
};


// --- App Definitions ---
export const APPS: AppDefinition[] = [
    { id: 'notepad', name: 'Notepad', icon: <NoteIcon />, component: Notepad, isDesktopShortcut: true, isPinned: true },
    { id: 'browser', name: 'Browser', icon: <BrowserIcon />, component: Browser, isDesktopShortcut: true, isPinned: true },
    { id: 'settings', name: 'Settings', icon: <SettingsIcon />, component: Settings, isDesktopShortcut: true },
    { id: 'clock', name: 'Clock', icon: <ClockIcon />, component: Clock, isDesktopShortcut: true, isPinned: true },
    { id: 'terminal', name: 'Terminal', icon: <TerminalIcon />, component: Terminal, isDesktopShortcut: true },
    { id: 'liquid-book-reader', name: 'Book Reader', icon: <BookIcon />, component: LiquidOSBookReader, isDesktopShortcut: true },
    { id: 'one-compiler', name: 'OneCompiler', icon: <OneCompilerIcon />, component: OneCompiler, isDesktopShortcut: true, opensMaximized: true },
    { id: 'calculator', name: 'Calculator', icon: <CalculatorIcon />, component: Calculator, isDesktopShortcut: true, isPinned: true },
    { id: 'calendar', name: 'Calendar', icon: <CalendarIcon />, component: Calendar, isDesktopShortcut: true, isPinned: true },
    { id: 'file-manager', name: 'File Manager', icon: <FileManagerIcon />, component: FileManager, isDesktopShortcut: true, isPinned: true }, // Added File Manager
];
